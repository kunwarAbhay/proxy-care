# Razorpay test-mode fixtures

Test mode only. Use a `rzp_test_` Key ID and the test Key Secret / webhook secret from the Razorpay
test dashboard, held in the CI secret store. Never use live keys or real customer credentials.

## Enabled payment methods (fill in before running `02_payment_methods.feature`)

The Proxy Care docs do not say which methods are enabled. Confirm on the Razorpay dashboard and tick:

| Method | Enabled? |
|---|---|
| Card (domestic) | ☐ |
| Card (international) | ☐ |
| UPI | ☐ |
| Net banking | ☐ |
| Wallet | ☐ |
| Pay Later / EMI / others | ☐ |

Delete the matching `Examples` rows for anything not enabled.

## Success fixtures

| Method | Value | Notes |
|---|---|---|
| Visa | 4100 2800 0000 1007 | any future expiry, any CVV |
| Mastercard | 5500 6700 0000 1002 | |
| RuPay | 6527 6589 0000 1005 | |
| UPI | success@razorpay | |
| Net banking | any bank → "Success" on mock page | |
| Wallet | any wallet → "Success" on mock page | |
| Card OTP | any 4–10 digit OTP | fewer than 4 digits = authentication failure |

## Failure cards (choose "Failure" on the mock bank page)

| Visa | Mastercard | error reason |
|---|---|---|
| 4100 2800 0008 0001 | 5305 6200 0005 0001 | insufficient_fund |
| 4100 2800 0006 0003 | 5305 6200 0003 0003 | card_declined |
| 4100 2800 0003 0006 | 5305 6200 0000 0006 | card_disabled_for_online_payments |
| 4100 2800 0001 0008 | 5305 6200 0008 0008 | card_number_invalid |
| 4100 2800 0002 0007 | 5305 6200 0009 0007 | gateway_technical_error |
| 4100 2800 0000 0009 | 5305 6200 0007 0009 | authentication_failed |
| 4100 2800 0009 0000 | 5305 6200 0006 0000 | payment_timed_out |
| 4100 2800 0007 0002 | 5305 6200 0004 0002 | payment_cancelled |

UPI failure: `failure@razorpay`. International (only if enabled): Visa 4012 8888 8888 1881.
Razorpay publishes no dedicated expired-card or invalid-CVV test cards; those cases are covered as Checkout
field validation (past expiry / short CVV).

Source: Razorpay test-integration and test-card docs, checked 2 Nov 2026. Re-verify before each release.

## Proxy Care seed data used by the features

| Item | Value |
|---|---|
| User | Asha Verma, +919800000001 |
| Second User (access tests) | Ravi Kumar, +919800000002 |
| Patient | Ramesh Verma, Father, 72, WHEELCHAIR (₹250/h, booking ₹1,249) |
| Caretakers | Sunita Rao (assigned), Imran Khan (other booking) |
| Booking | PC-2481, Apollo Hospital Bannerghatta, pickup 2026-11-02 10:00 IST |
| Hospital QR | merchant "Apollo Hospital Bannerghatta", MCC 8062, payee apollo.blr@upi (fictional) |
| Amounts | ride to hospital ₹286, hospital bill ₹500, ride home ₹312 |
