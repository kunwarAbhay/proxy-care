# Traceability: PRD 5 (cancellation, pro-rated adjustments) · Context §1 Refund entity (amount, reason
#               cancellation / diagnostic pro-rate, destination, status), §2 final fee strategy rule 4, F1
#               "Close visit & get ₹X back", B5 dialog note (5-7 working days)
# Refunds are system-initiated only. No admin or User "request refund" UI is documented.
# Razorpay Refunds API refunds to the original payment's source. The docs also say "bank account", which is
# only consistent if the original method was a bank-linked method (@pending-clarification).
@payments @refunds @api @gateway
Feature: Razorpay refunds for cancellations and pro-rated visits
  As a User
  I want refunds raised automatically against my original payment
  So that I get back exactly what the policy promises

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma" with patient "Ramesh Verma" (WHEELCHAIR)
    And booking "PC-2481" was paid ₹1,249 by captured Razorpay payment "pay_B01"

  # ---------- Cancellation refunds ----------

  @smoke
  Scenario: Partial refund for a cancellation more than 8 hours before pickup
    Given booking "PC-2481" is "WAITING"
    When Asha confirms cancellation more than 8 hours before pickup
    Then a Razorpay refund of 115000 paise is created on "pay_B01"
    And a Refund record stores booking "PC-2481", amount ₹1,150, reason "cancellation", the Razorpay Refund ID and status "pending"
    And Razorpay payment "pay_B01" shows amount_refunded 115000

  Scenario: Partial refund for a cancellation within 8 hours of pickup
    Given booking "PC-2481" is "WAITING"
    When Asha confirms cancellation 3 hours before pickup
    Then a Razorpay refund of 40000 paise is created on "pay_B01"

  # ---------- Pro-rated diagnostics refund (proposed rule) ----------

  @proposed-rule @pending-clarification
  Scenario Outline: Diagnostics-only visit under 3 hours refunds unused wage
    Given booking "PC-2481" has only the purpose "DIAGNOSTICS"
    And billable time from pickup OTP to Visit Completed is <actual>
    When the final caretaker bill is calculated
    Then billed time is <billed> and the refund is ₹<refund>
    And F1 offers "Close visit & get ₹<refund> back"
    When Asha taps "Close visit & get ₹<refund> back"
    Then a Razorpay refund of <refund_paise> paise with reason "diagnostic pro-rate" is created on "pay_B01"

    Examples:
      | actual  | billed  | refund | refund_paise |
      | 0 h 40m | 1 h 00m | 500    | 50000        |
      | 1 h 00m | 1 h 00m | 500    | 50000        |
      | 1 h 10m | 1 h 30m | 375    | 37500        |

  @proposed-rule
  Scenario: Non-diagnostics visit under 3 hours has no refund
    Given booking "PC-2481" has purposes "OPD"
    And billable time is 1 h 20m
    When the final caretaker bill is calculated
    Then billed time is 3 h 00m, the net is ₹0 and no refund is created

  # ---------- Refund status ----------

  Scenario Outline: Refund status follows Razorpay
    Given Refund "RF-01" for ₹1,150 is "pending"
    When Razorpay reports refund "rfnd_01" as "<rzp_status>"
    Then Refund "RF-01" is "<app_status>"
    And Asha's visit card in My visits shows "<chip>"

    Examples:
      | rzp_status | app_status | chip                     |
      | processed  | processed  | Cancelled · ₹1,150 refunded |

  @negative @pending-clarification
  Scenario: Refund fails at Razorpay
    Given Refund "RF-01" for ₹1,150 is "pending"
    When Razorpay reports refund "rfnd_01" as "failed"
    Then Refund "RF-01" is "failed"
    And the failure is raised for operations follow-up
    And the booking does not claim the refund was made
    # User messaging and retry policy for failed refunds are not documented.

  @pending-clarification
  Scenario: Refund delayed beyond the promised 5-7 working days
    Given Refund "RF-01" has been "pending" for more than 7 working days
    Then it appears in the refund ageing report
    # No ageing report or escalation is documented.

  # ---------- Guard rails ----------

  @negative @security
  Scenario Outline: Refund amount guard rails
    Given "pay_B01" captured 124900 paise and has already refunded <already> paise
    When the backend attempts a refund of <attempt> paise on "pay_B01"
    Then the refund is "<result>"

    Examples:
      | already | attempt | result   |
      | 0       | 115000  | created  |
      | 0       | 124900  | created  |
      | 0       | 124901  | refused  |
      | 115000  | 9900    | created  |
      | 115000  | 10000   | refused  |
      | 0       | 0       | refused  |
      | 0       | -100    | refused  |

  @negative
  Scenario Outline: Refund on an invalid payment is refused
    When the backend attempts a refund on payment "<payment>" in Razorpay status "<status>"
    Then Razorpay refuses the refund
    And no Refund record is marked created

    Examples:
      | payment     | status     |
      | pay_FAILED  | failed     |
      | pay_AUTH    | authorized |
      | pay_UNKNOWN | -          |

  @idempotency
  Scenario: Duplicate refund request for one cancellation
    Given Asha's cancellation of "PC-2481" created Refund "RF-01" of ₹1,150
    When the refund step is triggered again for the same cancellation
    Then exactly one Razorpay refund exists for that cancellation
    And total refunded on "pay_B01" is 115000 paise

  @mock-razorpay @negative
  Scenario: Razorpay times out while creating the refund
    Given the Razorpay Refunds API is stubbed to time out
    When Asha confirms cancellation of "PC-2481"
    Then booking "PC-2481" is "CANCELLED"
    And the refund is retried using the same idempotency reference
    And at most one Razorpay refund is created

  @security
  Scenario Outline: Only the system can create refunds
    When <actor> calls a refund endpoint for "pay_B01"
    Then the request is refused
    And no refund is created

    Examples:
      | actor                                |
      | User "Asha Verma"                    |
      | caretaker "Sunita Rao"               |
      | an unauthenticated client            |

  @ui @pending-clarification
  Scenario: Refund appears on the visit statement
    Given booking "PC-2481" was cancelled with a processed refund of ₹1,150
    When Asha opens the statement for "PC-2481"
    Then the statement shows the payment of ₹1,249 and the refund of ₹1,150
