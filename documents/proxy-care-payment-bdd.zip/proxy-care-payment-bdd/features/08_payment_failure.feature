# Traceability: Context §2 payment request status (PAYING -> FAILED, retry), §3 step 3 (failure with retry),
#               §8 payment states, B4 states (payment failed, cancelled at gateway), F1 states (payment failed)
@payments @failure @negative
Feature: Payment failures never look like success
  As a User
  I want failed payments reported clearly with a way to retry
  So that I never think I have paid when I have not, and I am never charged twice

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma" with verified mobile "+919800000001"

  @ui @api @smoke @REQ-B4
  Scenario: Booking payment fails and no booking is dispatched
    Given Asha is paying ₹1,249 for a new booking
    When Razorpay reports the payment as failed with reason "card_declined"
    Then the app shows the payment failure state with "Retry"
    And no booking in state "WAITING" exists for this draft
    And no caretaker receives a visit request
    And the booking draft details are kept so Asha can retry without re-entering them

  @ui @api @REQ-CTX3
  Scenario Outline: Failed payment request stays visible and retryable
    Given a "<type>" payment request "PR-1" for ₹<amount> is "PAYING"
    When Razorpay reports the payment as failed
    Then "PR-1" becomes "FAILED"
    And the app shows the failure state with "Retry"
    And "PR-1" appears in the Home pending list
    And the caretaker still sees the request as unpaid

    Examples:
      | type             | amount |
      | RIDE_TO_HOSPITAL | 286    |
      | HOSPITAL_BILL    | 500    |
      | RIDE_HOME        | 312    |
      | CARETAKER_FEE    | 250    |

  @ui @api
  Scenario: Retry after failure succeeds and leaves one captured payment
    Given payment request "PR-1" for ₹500 is "FAILED" after a declined card
    When Asha taps "Retry" and pays with UPI ID "success@razorpay"
    Then "PR-1" becomes "PAID"
    And exactly one captured Razorpay payment is linked to "PR-1"
    And the earlier failed attempt is kept in the payment record history

  @api @mock-razorpay
  Scenario Outline: Proxy Care backend errors during verification
    Given Asha has completed a payment in Checkout for "PR-1"
    And the Proxy Care verification endpoint responds with "<error>"
    Then the app does not show "₹500 paid"
    And the app shows a status-pending state and keeps checking the payment status
    And the final status shown matches the backend status after reconciliation

    Examples:
      | error                    |
      | HTTP 500                 |
      | HTTP 502                 |
      | HTTP 503                 |
      | no response in time      |

  @api
  Scenario Outline: Client errors from the Proxy Care payment API
    When the app calls the payment API with <problem>
    Then the backend responds with HTTP <status>
    And no Razorpay Order is created and no status changes

    Examples:
      | problem                                         | status |
      | no auth token                                   | 401    |
      | an expired auth token                           | 401    |
      | a payment request belonging to another User     | 403    |
      | a payment request ID that does not exist        | 404    |
      | a payment request already PAID                  | 409    |

  @api @webhook
  Scenario: Callback never arrives but Razorpay captured the payment
    Given Asha paid "PR-1" in Checkout and Razorpay captured the payment
    And the app never sent the Checkout response to the backend
    When the "payment.captured" webhook for that payment is received and verified
    Then "PR-1" becomes "PAID"
    And the app shows "₹500 paid" the next time it checks the status

  @api @mock-razorpay
  Scenario: Neither callback nor webhook arrives
    Given "PR-1" has been "PAYING" longer than the reconciliation interval
    When the backend reconciliation job asks Razorpay for the payments on the linked order
    Then "PR-1" is updated to match Razorpay: "PAID" if captured, "FAILED" if failed, payable again if no payment exists

  @api @security
  Scenario: Response missing mandatory fields is not treated as success
    Given Asha completed Checkout for "PR-1"
    When the app sends a verification call without razorpay_signature
    Then the backend rejects the call
    And "PR-1" is not marked "PAID" from this call

  @ui
  Scenario: Failure screen never shows success details
    Given a payment for "PR-1" has failed
    Then the screen does not show "₹500 paid", a receipt link or a transaction id as paid
    And "Retry" and a way back to the request are available

  @api @pending-clarification
  Scenario: Hospital desk is still waiting after repeated failures
    Given hospital bill payment request "PR-H-01" has failed 3 times
    Then the caretaker can tap "Remind family"
    # What happens at the hospital desk if the User cannot pay is not documented.
