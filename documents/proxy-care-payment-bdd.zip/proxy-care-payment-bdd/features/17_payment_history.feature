# Traceability: B8 Payments tab, B9 Payment details, F3 Visit statement, B7 My visits chips, §6 read models
# Search, filters, sorting controls and pagination are NOT documented for B8; they are not tested here.
@payments @history @ui
Feature: Payment history, payment details and receipts
  As a User
  I want to see every payment I approved, with its gateway reference and bills
  So that I can check and keep records of what I paid

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma"

  @smoke
  Scenario: Payments tab groups paid items by visit and includes the booking charge
    Given booking "PC-2481" for "Ramesh Verma" on 2026-10-24 has these paid items:
      | type             | description                         | amount |
      | BOOKING          | Booking charge                      | 1249   |
      | RIDE_TO_HOSPITAL | Cab to Apollo Hospital               | 286    |
      | HOSPITAL_BILL    | OPD registration + consultation fee  | 500    |
    And a "REQUESTED" ride home request of ₹312 exists on the same booking
    When Asha opens the Payments tab
    Then a group shows the visit name, date and "PC-2481"
    And the group lists 3 rows, each with type icon, description, payee and time, amount and "Paid"
    And the unpaid ₹312 request is not listed

  Scenario: Empty Payments tab
    Given Asha has never paid anything
    When Asha opens the Payments tab
    Then an empty state is shown

  Scenario Outline: Payment details by type
    Given a paid "<type>" item on booking "PC-2481" with Razorpay Payment ID "pay_TEST001"
    When Asha opens it from the Payments tab
    Then the details show a "Paid" chip, description and amount
    And the details show "<type_specific>"
    And the details show paid on, method, transaction id and visit

    Examples:
      | type             | type_specific                                 |
      | HOSPITAL_BILL    | paid to, QR check, requested by and time       |
      | RIDE_TO_HOSPITAL | paid to, route, requested by and time          |
      | RIDE_HOME        | paid to, route, requested by and time          |
      | CARETAKER_FEE    | paid to Proxy Care, requested by and time      |
      | BOOKING          | the price breakdown instead of request rows    |

  Scenario Outline: Bills section on payment details
    Given a paid "<type>" item
    When Asha opens its payment details
    Then the Bills section shows "<bill>"

    Examples:
      | type             | bill                                        |
      | HOSPITAL_BILL    | the hospital bill attached by the caretaker |
      | RIDE_TO_HOSPITAL | the ride trip receipt                       |
      | CARETAKER_FEE    | the caretaker bill                          |

  Scenario: Hospital bill not yet attached
    Given a paid hospital bill whose status is "PAID_BILL_PENDING"
    When Asha opens its payment details
    Then the Bills section shows that the caretaker has not attached the bill yet

  @smoke
  Scenario: Download receipt
    Given a paid hospital bill of ₹500 with Razorpay Payment ID "pay_TEST001"
    When Asha taps "Download receipt"
    Then a PDF receipt is downloaded
    And it shows amount ₹500, the description, the paid date, the method and "pay_TEST001"

  Scenario: Visit statement totals and split
    Given booking "PC-2481" is "SETTLED" with payments booking ₹1,249, rides ₹598, hospital ₹500 and caretaker fee ₹250
    When Asha opens the visit statement
    Then total visit cost shows ₹2,597
    And the split by caretaker, hospital, platform and rides adds up to ₹2,597
    And the User's payments are listed in time order
    And "Download invoice" produces a PDF

  Scenario: Gateway references match Razorpay
    Given a paid item with Razorpay Payment ID "pay_TEST001" captured for 50000 paise
    When Asha opens its payment details
    Then the amount shown is ₹500
    And the transaction id shown can be found in the Razorpay dashboard with the same amount and status

  Scenario Outline: My visits status chips reflect payment state
    Given a booking in state "<state>" <extra>
    When Asha opens My visits
    Then the card shows "<chip>" under "<tab>"

    Examples:
      | state     | extra                               | chip                          | tab      |
      | WAITING   |                                     | Finding a caretaker           | Upcoming |
      | ASSIGNED  | with caretaker Sunita               | Caretaker assigned · Sunita   | Upcoming |
      | SETTLED   |                                     | Completed · all settled       | Past     |
      | CANCELLED | with refund ₹1,150                  | Cancelled · ₹1,150 refunded   | Past     |

  @security
  Scenario: Another User's payment cannot be opened
    Given User "Ravi Kumar" has a paid item "PR-RAVI-1"
    When Asha opens the payment details for "PR-RAVI-1" by its ID
    Then access is refused and no details are shown
