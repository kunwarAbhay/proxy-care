# Traceability: Context §1 Dispute, §2 payment request status DISPUTED (hospital bills only), hospital bill status
#               DISPUTED, H5 "This bill looks wrong", F2 "Something looks wrong", §7 Hospital bill disputed,
#               B9 "Report a problem with this payment"
@payments @dispute
Feature: Disputing a hospital bill before paying
  As a User
  I want to flag a hospital charge that looks wrong instead of paying it
  So that nothing is paid until the problem is resolved

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma" and caretaker "Sunita Rao" on booking "PC-2481"
    And hospital bill "HB-01" for ₹500 is "PAYMENT_REQUESTED" with payment request "PR-H-01" in "REQUESTED"

  @ui @api @smoke
  Scenario: User disputes a hospital payment request
    When Asha opens "PR-H-01" and taps "This bill looks wrong"
    Then "PR-H-01" becomes "DISPUTED"
    And hospital bill "HB-01" becomes "DISPUTED"
    And no Razorpay Order is created and nothing is paid
    And Sunita's bill status shows the disputed state

  @api @negative
  Scenario: A disputed request cannot be paid
    Given "PR-H-01" is "DISPUTED"
    When Asha's app requests to pay "PR-H-01"
    Then the backend refuses and no Razorpay Order is created

  @ui
  Scenario: Disputing from the unpaid requests screen
    Given booking "PC-2481" is "COMPLETED" and "PR-H-01" blocks closing
    When Asha taps "Something looks wrong"
    Then the hospital payment request screen for "PR-H-01" opens

  @negative
  Scenario Outline: Only unpaid hospital bill requests can be disputed
    Given a payment request of type "<type>" in status "<status>"
    Then "This bill looks wrong" is <visibility>

    Examples:
      | type             | status    | visibility  |
      | HOSPITAL_BILL    | REQUESTED | available   |
      | HOSPITAL_BILL    | FAILED    | available   |
      | HOSPITAL_BILL    | PAID      | unavailable |
      | RIDE_TO_HOSPITAL | REQUESTED | unavailable |

  @pending-clarification
  Scenario: Disputed request and settlement
    Given "PR-H-01" is "DISPUTED"
    When Sunita marks "Visit Completed"
    Then the settlement result follows the confirmed rule for disputed requests
    # Undocumented: does a DISPUTED request block F2/F1, who resolves it, and can it return to REQUESTED?

  @pending-clarification
  Scenario: Problem reported after payment
    Given "PR-H-01" is "PAID" and the hospital bill is attached
    When Asha taps "Report a problem with this payment" on the payment details screen
    Then a dispute is recorded against booking "PC-2481"
    # Dispute flow after payment and any resulting refund are not designed.
