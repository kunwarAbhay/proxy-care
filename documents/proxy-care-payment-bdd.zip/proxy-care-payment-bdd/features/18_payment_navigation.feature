# Traceability: Context §3, §4 screen flows (B4->B5, U2b->H6, U3b->U4, H5, F2->F1->F3, B1/B7/B8/B9),
#               §5 caretaker flows (P9a->H1, D4a->D5, H3<->H4, D5->F4)
@payments @navigation @ui
Feature: Navigation into, through and out of payments
  As a User or caretaker
  I want each payment to land me on the right next screen
  So that the visit flow continues without confusion

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma" and caretaker "Sunita Rao" on booking "PC-2481"

  @smoke
  Scenario Outline: Where the User lands after each payment outcome
    Given Asha is paying from "<pay_screen>"
    When the payment outcome is "<outcome>"
    Then Asha sees "<result_state>"
    And the next action leads to "<next_screen>"

    Examples:
      | pay_screen                | outcome   | result_state            | next_screen                 |
      | Review · Confirm & Pay    | success   | ₹1,249 paid · Continue  | Finding caretaker           |
      | Review · Confirm & Pay    | failure   | failure with Retry      | Razorpay Checkout again     |
      | Review · Confirm & Pay    | cancelled | cancelled with Retry    | Review · Confirm & Pay      |
      | Ride payment request      | success   | ₹286 paid · Continue    | Services status             |
      | Hospital payment request  | success   | ₹500 paid with a note that the bill will be attached | Services status (assumed; not documented) |
      | Ride home payment request | success   | ₹312 paid · Continue    | Visit completed             |
      | Final caretaker bill      | success   | settled                 | Visit statement             |
      | Unpaid requests           | success   | item cleared            | Unpaid requests             |

  Scenario: Visit statement closes to Home
    Given Asha is on the visit statement
    When Asha closes it
    Then Home is shown

  Scenario: Final bill is reached through unpaid requests when anything is unpaid
    Given a hospital request of ₹500 is unpaid
    When Asha taps "Review final bill" on the visit completed screen
    Then the unpaid requests screen opens instead of the final bill

  Scenario Outline: Opening payment screens from tabs
    When Asha <action>
    Then "<screen>" opens

    Examples:
      | action                                    | screen          |
      | taps Payments in the bottom navigation    | Payments        |
      | taps a row in Payments                    | Payment details |
      | taps a past visit card in My visits       | Visit statement |
      | taps a cancelled visit card in My visits  | Visit statement |

  Scenario Outline: Caretaker screens after the family pays
    Given Sunita is on "<screen>" waiting for Asha
    When Asha's payment is verified
    Then "Continue" on "<screen>" is enabled and leads to "<next>"

    Examples:
      | screen               | next              |
      | Ride payment (P9a)   | Services to-do    |
      | Ride payment (D4a)   | Handover          |

  Scenario: Caretaker moves between bill status and attach screens
    Given the hospital bill is "PAID_BILL_PENDING"
    When Sunita taps "Attach hospital bill" on Bill status
    Then "Attach hospital bill" opens
    When Sunita attaches the bill
    Then Sunita returns to Bill status showing "Hospital bill attached · shared with Asha"
    When Sunita taps "Back to services"
    Then the services to-do screen opens

  Scenario: Visit completed leads the caretaker to earnings
    When Sunita marks "Visit Completed"
    Then visit earnings opens
    And Home's ongoing card shows "View payout status" instead of the resume arrow

  @negative
  Scenario: Back from Razorpay Checkout returns to the pay screen, not to success
    Given Razorpay Checkout is open for a ₹500 hospital request
    When Asha presses the device back button
    Then the hospital payment request screen is shown with the request still payable

  @negative
  Scenario: Back after a successful payment does not reopen Checkout
    Given Asha has just seen "₹500 paid"
    When Asha presses the device back button
    Then Checkout does not reopen
    And the request shows as paid

  @negative
  Scenario: Re-opening a paid request from a stale banner or notification
    Given a hospital request of ₹500 is already "PAID"
    When Asha taps an old banner or push for that request
    Then the screen shows the paid state and no "Approve & Pay" button

  @negative
  Scenario: Deep link to a pay screen of a request that no longer exists
    When Asha opens a pay screen link with an unknown payment request ID
    Then an error state is shown with a way back to Home
