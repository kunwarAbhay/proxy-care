# Traceability: Context §2 Booking state, Payment request status, Hospital bill status, Caretaker earning status;
#               §6 read models; §8 "app resumed mid-payment (poll status)"
# Only statuses that exist in the docs are used. Razorpay statuses (order: created/attempted/paid;
# payment: created/authorized/captured/refunded/failed; refund: pending/processed/failed) are mapped to them.
@payments @status @api
Feature: Payment status lifecycle and consistency
  As the platform
  I want every payment-related record to move only through its documented states
  So that the User app, the Caretaker app and Razorpay always agree

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma" and caretaker "Sunita Rao" on booking "PC-2481"

  # ---------- Payment request ----------

  @smoke
  Scenario Outline: Allowed payment request transitions
    Given payment request "PR-1" of type "<type>" is "<from>"
    When <trigger>
    Then "PR-1" becomes "<to>"

    Examples:
      | type          | from      | trigger                                           | to       |
      | HOSPITAL_BILL | REQUESTED | Asha taps "Approve & Pay" and Checkout opens       | PAYING   |
      | HOSPITAL_BILL | PAYING    | a captured payment is verified                     | PAID     |
      | HOSPITAL_BILL | PAYING    | Razorpay reports the payment failed                | FAILED   |
      | HOSPITAL_BILL | FAILED    | Asha taps "Retry" and Checkout opens               | PAYING   |
      | HOSPITAL_BILL | REQUESTED | Asha taps "This bill looks wrong" and confirms     | DISPUTED |
      | RIDE_HOME     | PAYING    | a captured payment is verified                     | PAID     |

  @negative
  Scenario Outline: Forbidden payment request transitions
    Given payment request "PR-1" of type "<type>" is "<from>"
    When the system receives a request to move it to "<to>"
    Then the transition is refused and "PR-1" stays "<from>"

    Examples:
      | type             | from      | to       |
      | HOSPITAL_BILL    | PAID      | FAILED   |
      | HOSPITAL_BILL    | PAID      | REQUESTED |
      | HOSPITAL_BILL    | PAID      | DISPUTED |
      | HOSPITAL_BILL    | REQUESTED | PAID     |
      | RIDE_TO_HOSPITAL | REQUESTED | DISPUTED |
      | CARETAKER_FEE    | REQUESTED | DISPUTED |

  @pending-clarification
  Scenario: Moving from PAYING back to REQUESTED when the User abandons Checkout
    Given payment request "PR-1" is "PAYING"
    When Asha closes Checkout without paying and no payment exists on the order
    Then "PR-1" is shown to Asha as payable with "Retry"
    # The docs do not say whether the stored status returns to REQUESTED, stays PAYING or becomes FAILED.

  # ---------- Booking ----------

  Scenario Outline: Booking states driven by payments
    Given booking "PC-2481" is "<from>"
    When <payment_event>
    Then booking "PC-2481" becomes "<to>"

    Examples:
      | from            | payment_event                                       | to        |
      | PAYMENT_PENDING | the booking charge is captured and verified         | WAITING   |
      | WAITING         | Asha confirms cancellation                          | CANCELLED |
      | COMPLETED       | the CARETAKER_FEE request is captured and verified  | SETTLED   |

  @pending-clarification
  Scenario: Booking settles when the final net is zero or a refund
    Given booking "PC-2481" is "COMPLETED" with all requests paid
    And the final caretaker bill net is ₹0
    When Asha taps "Approve & close visit"
    Then booking "PC-2481" becomes "SETTLED"
    # SETTLED is defined as "caretaker fee paid"; the zero/refund case has no fee request. Confirm.

  # ---------- Hospital bill ----------

  Scenario Outline: Hospital bill states follow its payment request
    Given hospital bill "HB-01" is "<from>"
    When <event>
    Then hospital bill "HB-01" becomes "<to>"

    Examples:
      | from              | event                                              | to                |
      | PAYMENT_REQUESTED | its payment request is captured and verified       | PAID_BILL_PENDING |
      | PAID_BILL_PENDING | Sunita attaches the hospital's bill                | BILL_ATTACHED     |
      | PAYMENT_REQUESTED | Asha disputes the request                           | DISPUTED          |

  @negative
  Scenario: QR_MISMATCH bills never move to a payable state
    Given hospital bill "HB-02" is "QR_MISMATCH"
    Then no payment request exists for "HB-02"
    And "HB-02" cannot become "PAYMENT_REQUESTED"

  # ---------- Caretaker earning ----------

  Scenario Outline: Caretaker earning states follow settlement
    Given Sunita's earning for "PC-2481" is "<from>"
    When <event>
    Then the earning becomes "<to>"

    Examples:
      | from         | event                                              | to           |
      | ON_HOLD      | the last unpaid request on the booking is paid     | AWAITING_FEE |
      | AWAITING_FEE | the CARETAKER_FEE request is paid                  | IN_WALLET    |
      | IN_WALLET    | Sunita's withdrawal is processed                    | WITHDRAWN    |

  # ---------- Consistency and polling ----------

  @ui @smoke
  Scenario: App resumed mid-payment polls the backend
    Given payment request "PR-1" is "PAYING" and the app was in the background
    When Asha brings the app to the foreground
    Then the app asks the backend for the status of "PR-1"
    And the screen shows the backend status, not a cached one

  @ui
  Scenario Outline: The same request shows the same status everywhere
    Given payment request "PR-1" is "<status>"
    Then Asha's pay screen, Asha's Home list and Sunita's request screen all reflect "<status>"

    Examples:
      | status    |
      | REQUESTED |
      | PAYING    |
      | PAID      |
      | FAILED    |

  @reconciliation
  Scenario Outline: Reconciliation aligns the app with Razorpay
    Given payment request "PR-1" is "PAYING"
    And Razorpay reports the latest payment on its order as "<rzp_status>"
    When the reconciliation job runs
    Then "PR-1" becomes "<app_status>"

    Examples:
      | rzp_status | app_status |
      | captured   | PAID       |
      | failed     | FAILED     |
      | authorized | PAYING     |

  @reconciliation @pending-clarification
  Scenario: Captured payment found for a request already PAID by another payment
    Given payment request "PR-1" is "PAID" by "pay_A"
    And reconciliation finds a second captured payment "pay_B" on an order linked to "PR-1"
    Then "pay_B" is flagged as a duplicate charge
    And a refund of "pay_B" is raised
    # Automatic refund of duplicate captures is not documented; confirm the expected handling.
