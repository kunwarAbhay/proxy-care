# Traceability: Context §3 (gateway redirect), B9 ("method" row) · PRD 3.1 step 3, 3.2 step 5
# IMPORTANT: The documentation does NOT list which Razorpay payment methods are enabled.
# Every scenario here is tagged @pending-method-confirmation. Before running, set the enabled list in
# test-data/razorpay_test_fixtures.md and drop the Examples rows for methods that are not enabled.
# Field-level validation inside these scenarios is Razorpay Checkout's own UI, not Proxy Care's.
@payments @methods @gateway @sandbox @pending-method-confirmation
Feature: Razorpay payment methods offered in Checkout
  As a User paying a booking charge or a payment request
  I want to pay with any method Proxy Care has enabled in Razorpay
  So that I can complete the payment the way I prefer

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma" with verified mobile "+919800000001"
    And a "REQUESTED" hospital bill payment request for ₹500 on booking "PC-2481"
    And Asha has tapped "Approve & Pay" and Razorpay Checkout is open for 50000 paise "INR"

  @ui
  Scenario: Checkout lists only the methods enabled for the Proxy Care account
    Then Razorpay Checkout lists exactly the payment methods configured as enabled for the Proxy Care account
    And no payment method outside that configuration is offered

  # ---------- Success per method ----------

  @ui @api @smoke
  Scenario Outline: Successful payment with each enabled method
    When Asha pays using method "<method>" with test fixture "<fixture>"
    And the backend verifies the payment
    Then the payment request status becomes "PAID"
    And the payment detail screen shows method "<method_label>"

    Examples: Cards
      | method | fixture                                   | method_label |
      | card   | Visa 4100 2800 0000 1007, future expiry, any CVV       | Card |
      | card   | Mastercard 5500 6700 0000 1002, future expiry, any CVV | Card |
      | card   | RuPay 6527 6589 0000 1005, future expiry, any CVV      | Card |

    Examples: UPI
      | method | fixture          | method_label |
      | upi    | success@razorpay | UPI          |

    Examples: Net banking and wallets
      | method     | fixture                                 | method_label |
      | netbanking | any listed bank, choose Success on mock page   | Net banking |
      | wallet     | any listed wallet, choose Success on mock page | Wallet      |

  # ---------- Gateway-side failures per method ----------

  @ui @api @negative
  Scenario Outline: Card failure codes from Razorpay test cards keep the request unpaid
    When Asha pays by card with test card "<card>" and selects "Failure" on the mock bank page
    Then Razorpay reports the payment as failed with reason "<reason>"
    And the app shows the payment failure state with a "Retry" option
    And the payment request status becomes "FAILED"
    And no "₹500 paid" success state is shown

    Examples:
      | card                | reason                            |
      | 4100 2800 0008 0001 | insufficient_fund                 |
      | 4100 2800 0006 0003 | card_declined                     |
      | 4100 2800 0003 0006 | card_disabled_for_online_payments |
      | 4100 2800 0001 0008 | card_number_invalid               |
      | 4100 2800 0002 0007 | gateway_technical_error           |
      | 4100 2800 0000 0009 | authentication_failed             |
      | 4100 2800 0009 0000 | payment_timed_out                 |
      | 4100 2800 0007 0002 | payment_cancelled                 |

  @ui @negative
  Scenario: Card OTP authentication failure
    When Asha pays by card with test card "4100 2800 0000 1007"
    And Asha enters an OTP of fewer than 4 digits on the mock authentication page
    Then the payment is not completed
    And the payment request is not marked "PAID"

  @ui @api @negative
  Scenario: UPI payment fails
    When Asha pays using UPI ID "failure@razorpay"
    Then Razorpay reports the payment as failed
    And the payment request status becomes "FAILED"
    And Asha can retry with "Approve & Pay"

  @ui @api @negative
  Scenario Outline: Net banking or wallet failure on the mock page
    When Asha chooses "<method>" and selects "Failure" on the Razorpay mock page
    Then the payment request status becomes "FAILED"
    And the app shows the failure state with "Retry"

    Examples:
      | method     |
      | netbanking |
      | wallet     |

  # ---------- Checkout field validation (Razorpay-owned UI) ----------

  @ui @negative
  Scenario Outline: Checkout blocks invalid card input before submission
    When Asha enters card number "<number>", expiry "<expiry>" and CVV "<cvv>" in Razorpay Checkout
    Then Razorpay Checkout shows a field-level error on "<field>"
    And the Checkout pay button stays disabled or the submission is rejected
    And no payment attempt reaches the Proxy Care backend as successful

    Examples:
      | number              | expiry | cvv | field       |
      |                     | 12/30  | 123 | card number |
      | 4100 2800 0000 1008 | 12/30  | 123 | card number |
      | 4100 2800 0000 1007 |        | 123 | expiry      |
      | 4100 2800 0000 1007 | 01/20  | 123 | expiry      |
      | 4100 2800 0000 1007 | 13/30  | 123 | expiry      |
      | 4100 2800 0000 1007 | 12/30  |     | CVV         |
      | 4100 2800 0000 1007 | 12/30  | 12  | CVV         |

  @ui @negative
  Scenario Outline: Checkout rejects badly formatted UPI IDs
    When Asha enters UPI ID "<vpa>" in Razorpay Checkout
    Then Razorpay Checkout shows an invalid UPI ID message
    And no payment is created

    Examples:
      | vpa              |
      |                  |
      | asha             |
      | asha@            |
      | @razorpay        |
      | asha verma@upi   |

  @ui @negative
  Scenario: International card is refused when international payments are not enabled
    Given international card payments are not enabled for the Proxy Care account
    When Asha pays by card with international test card "4012 8888 8888 1881"
    Then the payment is not completed
    And the payment request is not marked "PAID"

  # ---------- Amount limits ----------

  @api @boundary
  Scenario Outline: Amount boundaries for a payment request order
    Given a payment request amount of <paise> paise
    When the backend creates the Razorpay Order
    Then the order creation result is "<result>"

    Examples:
      | paise | result   |
      | 100   | created  |
      | 99    | rejected |
      | 0     | rejected |

  @api @boundary @pending-clarification
  Scenario: Amount above the method's per-transaction limit
    Given a hospital bill payment request whose amount exceeds the configured per-transaction limit for UPI
    When Asha opens Razorpay Checkout for that request
    Then UPI is unavailable or the UPI attempt is rejected by Razorpay
    And other enabled methods can still be used
    # Maximum amount per request and per method is not documented.
