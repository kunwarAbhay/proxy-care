# Traceability: Context §3 "idempotency on repeat taps", §8 "app resumed mid-payment (poll status)",
#               Entity doc webhook_events primary key, bookings.idempotency_key ("FOR LATER")
# Goal: no retry, repeat or race ever produces a second charge, capture, refund or business effect.
@payments @idempotency @reliability @api
Feature: Retries, duplicates and recovery without double effects
  As the platform
  I want every payment operation to be safe to repeat
  So that Users are never charged twice and records are never applied twice

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma"

  @ui @smoke
  Scenario: Many taps on Confirm & Pay create one booking and one order
    Given Asha is on "Review · Confirm & Pay" for ₹1,249 with the policy ticked
    When Asha taps "Confirm & Pay ₹1,249" 5 times rapidly
    Then the button is disabled after the first tap
    And exactly one Razorpay Order is created
    And after payment exactly one booking exists for this draft

  @smoke
  Scenario: Same booking draft submitted from two devices
    Given Asha is signed in on two phones with the same booking draft
    When both phones tap "Confirm & Pay" at the same time
    Then at most one booking can be paid for that draft
    # Booking idempotency key is marked "FOR LATER" in the entity design (@pending-clarification).

  Scenario: Same payment request paid from two devices
    Given hospital request "PR-H-01" for ₹500 is "REQUESTED"
    When Asha opens Checkout for "PR-H-01" on two phones and completes payment on both
    Then "PR-H-01" is "PAID" once
    And the second captured payment is detected as a duplicate and refunded
    # Duplicate-capture handling is not documented (@pending-clarification).

  Scenario: Timeout on the app, success at Razorpay
    Given Asha completed a payment for "PR-H-01" and the verification call timed out on the app
    When Asha taps "Retry"
    Then the app first checks the status of "PR-H-01"
    And because it is "PAID" no new Checkout is opened

  Scenario: Payment completes after the user closed Checkout
    Given Asha started a UPI payment for "PR-H-01" and closed Checkout before approving it in her UPI app
    When Asha approves the UPI request later and Razorpay captures it
    Then the webhook marks "PR-H-01" as "PAID"
    And Asha's next view of "PR-H-01" shows paid

  Scenario: App restarted during processing
    Given "PR-H-01" is "PAYING"
    When the app is force-closed and relaunched
    Then the status shown comes from the backend
    And "Approve & Pay" is offered only if the backend says the request is still payable

  Scenario Outline: Repeated backend operations
    Given <operation> has already succeeded once
    When the same <operation> is repeated with the same idempotency reference
    Then the original result is returned
    And no new <side_effect> is created

    Examples:
      | operation                                    | side_effect           |
      | order creation for "PR-H-01"                 | Razorpay Order        |
      | verification of "pay_H01"                    | Payment record        |
      | capture of "pay_H01"                         | capture               |
      | cancellation refund for "PC-2481"            | Razorpay refund       |
      | creating the CARETAKER_FEE request           | payment request       |
      | crediting Sunita's earning for "PC-2481"     | wallet credit         |
      | caretaker withdrawal of ₹1,000               | RazorpayX payout      |

  Scenario: Repeated "Send to family" creates one hospital request
    Given caretaker "Sunita Rao" is on "Payment request details" with ₹500 and a description
    When Sunita taps "Send to family" twice on a slow network
    Then exactly one hospital bill and one payment request exist

  Scenario: Repeated "Request ₹286 from family" creates one ride request
    Given the ride to hospital is "TRIP_COMPLETED" with fare ₹286
    When Sunita taps "Request ₹286 from family" twice
    Then exactly one "RIDE_TO_HOSPITAL" request exists for that ride

  @ui
  Scenario: Optimistic UI rolls back when a payment-related action fails
    Given Sunita ticks a handover checklist item and the save fails
    Then the tick is rolled back and an error is shown

  Scenario: Reconciliation is safe to run repeatedly
    Given the reconciliation job has already aligned every "PAYING" request with Razorpay
    When the job runs again
    Then no status, notification or ledger entry changes
