# Traceability: PRD 3.1 step 4, 3.2, 3.4, 3.5, 3.6 · Context §2 state machines, §7 realtime events,
#               screens B4->B5, P9a, D4a, H3, H4, F1->F3, F4
# Each scenario starts from a backend-verified captured payment (see 11_razorpay_signature_verification and
# 10_razorpay_webhooks for how "verified" is reached).
@payments @success @api @ui
Feature: Business effects of a successful payment
  As the platform
  I want each verified payment to drive exactly the documented next step
  So that the visit moves forward and every party sees the same truth

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma" with patient "Ramesh Verma" (WHEELCHAIR)
    And caretaker "Sunita Rao" is approved and online

  @smoke @REQ-B4 @REQ-B5
  Scenario: Booking charge success creates a WAITING booking and broadcasts it
    Given Asha's booking payment of ₹1,249 is captured and verified
    Then a booking is created with state "WAITING"
    And a Payment record with no payment request ID and amount ₹1,249 is linked to the booking
    And the booking request is broadcast to nearby online caretakers
    And "Finding caretaker" shows "sent to N caretakers nearby" and "₹1,249 paid"

  @REQ-P9a @REQ-U2b
  Scenario Outline: Ride payment success unblocks the caretaker
    Given a "<type>" payment request of ₹<amount> on booking "PC-2481" is "PAYING"
    And caretaker Sunita is on the "<caretaker_screen>" screen showing "Payment request sent to Asha"
    When the payment is captured and verified
    Then the request becomes "PAID"
    And Sunita's screen changes to "Asha paid"
    And the "Continue" button on "<caretaker_screen>" becomes enabled
    And the ride for leg "<leg>" is marked paid
    And Asha is taken to "<user_next>" after "Continue"

    Examples:
      | type             | amount | caretaker_screen | leg         | user_next        |
      | RIDE_TO_HOSPITAL | 286    | Ride payment     | TO_HOSPITAL | Services status  |
      | RIDE_HOME        | 312    | Ride payment     | TO_HOME     | Visit completed  |

  @REQ-H3 @REQ-H4 @REQ-B9
  Scenario: Hospital bill payment success asks the caretaker to attach the hospital's bill
    Given hospital bill "HB-01" for ₹500 is "PAYMENT_REQUESTED" and its payment request is "PAYING"
    When the payment is captured and verified
    Then the payment request becomes "PAID"
    And hospital bill "HB-01" becomes "PAID_BILL_PENDING"
    And Sunita sees the realtime alert "Asha paid ₹500" on Bill status
    And Bill status shows "Attach hospital bill" with "Take photo" and "Upload"
    And Asha sees the paid state with a note that the caretaker will attach the hospital's bill
    When Sunita attaches a readable photo of the bill and taps "Attach & share with Asha"
    Then hospital bill "HB-01" becomes "BILL_ATTACHED" with uploadedBy, uploadedAt, file name and size
    And Bill status shows "Hospital bill attached · shared with Asha"
    And the bill appears in the "Bills" section of the payment detail for "HB-01" on Asha's app

  @REQ-F1 @REQ-F4 @REQ-PRD-3.6
  Scenario: Caretaker fee success settles the booking and credits the earnings wallet
    Given booking "PC-2481" is "COMPLETED" with all other payment requests "PAID"
    And a "CARETAKER_FEE" payment request of ₹250 is "PAYING"
    And Sunita's visit earning is "AWAITING_FEE"
    When the payment is captured and verified
    Then the payment request becomes "PAID"
    And booking "PC-2481" becomes "SETTLED"
    And Sunita's visit earning becomes "IN_WALLET" and a caretaker bill is generated
    And Sunita's earnings wallet balance increases by her visit earning
    And Asha is taken to the visit statement

  @REQ-B8 @REQ-B9
  Scenario: Paid request appears in the Payments tab with gateway references
    Given payment request "PR-H-01" for ₹500 has just become "PAID" with Razorpay Payment ID "pay_TEST001"
    When Asha opens the Payments tab
    Then "PR-H-01" is listed under booking "PC-2481" with description, payee, time, "₹500" and "Paid"
    When Asha opens it
    Then payment details show paid to, QR check, requested by and time, paid on, method and transaction id "pay_TEST001"

  @REQ-B1
  Scenario: Paid request leaves the Home pending list
    Given Asha has 2 "REQUESTED" payment requests on Home
    When one of them becomes "PAID"
    Then the Home pending list shows 1 item with count badge 1
