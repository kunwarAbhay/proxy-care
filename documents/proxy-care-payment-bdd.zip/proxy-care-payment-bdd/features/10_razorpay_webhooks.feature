# Traceability: Context §3 "handle gateway callback/webhook", Entity doc webhook_events
#               (primary key provider + event_id; processed_at; error)
# Razorpay behaviour used here: X-Razorpay-Signature = HMAC-SHA256 of the raw body with the webhook secret;
# x-razorpay-event-id is unique per event; delivery is at-least-once, not ordered; non-2xx or a response
# slower than 5 s is retried with backoff for up to 24 h, after which the webhook is disabled.
# All scenarios use a webhook simulator that signs payloads with the test webhook secret (@webhook-sim).
@payments @webhooks @api @webhook-sim
Feature: Razorpay webhook processing
  As the Proxy Care backend
  I want to accept only authentic Razorpay events and apply each one once, in a safe order
  So that payment and refund state always matches Razorpay

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And the webhook endpoint is configured with the test webhook secret
    And payment request "PR-H-01" for ₹500 is "PAYING" with Razorpay Order "order_H01"

  # ---------- Authenticity ----------

  @smoke @security
  Scenario: Valid signed event is stored and processed
    When Razorpay sends "payment.captured" for "pay_H01" on "order_H01" for 50000 paise with event id "evt_001" and a valid signature
    Then the endpoint responds 2xx within 5 seconds
    And a webhook event is stored with provider "RAZORPAY", event id "evt_001", type "payment.captured" and the payload
    And processed_at is set
    And "PR-H-01" becomes "PAID"

  @security @negative
  Scenario Outline: Unauthentic events are rejected without side effects
    When a request arrives at the webhook endpoint with <problem>
    Then the endpoint rejects it with a non-2xx response
    And no business record changes
    And "PR-H-01" stays "PAYING"

    Examples:
      | problem                                                     |
      | no X-Razorpay-Signature header                              |
      | a signature computed with a different secret                |
      | a valid signature but a body modified after signing         |
      | a signature computed over re-serialised JSON instead of the raw body |
      | an empty body                                               |

  @negative
  Scenario Outline: Signed but unusable payloads
    When Razorpay sends a correctly signed event <problem>
    Then the event is stored with an error and without a business update
    And "PR-H-01" stays "PAYING"

    Examples:
      | problem                                         |
      | that is not valid JSON                          |
      | with no "event" field                           |
      | of type "payment.captured" with no payment entity |
      | for order "order_UNKNOWN" not known to Proxy Care |
      | with currency "USD"                             |

  @negative
  Scenario: Unsubscribed event types are acknowledged and ignored
    When Razorpay sends a correctly signed event of a type Proxy Care does not handle
    Then the endpoint responds 2xx
    And no business record changes

  # ---------- Event handling ----------

  Scenario: payment.authorized does not mark the request paid
    When Razorpay sends "payment.authorized" for "pay_H01" on "order_H01"
    Then "PR-H-01" stays "PAYING"

  Scenario: payment.failed marks the request failed
    When Razorpay sends "payment.failed" for "pay_H01" on "order_H01" with reason "card_declined"
    Then "PR-H-01" becomes "FAILED"
    And Asha receives a payment failed update

  Scenario: order.paid confirms the request as paid
    When Razorpay sends "order.paid" for "order_H01" with amount_paid 50000
    Then "PR-H-01" becomes "PAID"

  Scenario Outline: Refund events update the refund
    Given a cancellation Refund "RF-01" of ₹1,150 exists with Razorpay Refund "rfnd_01" in status "<before>"
    When Razorpay sends "<event>" for "rfnd_01"
    Then Refund "RF-01" status becomes "<after>"

    Examples:
      | before  | event            | after     |
      | pending | refund.created   | pending   |
      | pending | refund.processed | processed |
      | pending | refund.failed    | failed    |

  # ---------- Idempotency ----------

  @idempotency @smoke
  Scenario: Same event delivered twice is applied once
    Given Razorpay sent "payment.captured" for "pay_H01" with event id "evt_001" and it was processed
    When Razorpay delivers event id "evt_001" again
    Then the endpoint responds 2xx
    And only one webhook event row exists for provider "RAZORPAY" and event id "evt_001"
    And "PR-H-01" stays "PAID" with one Payment record
    And no second notification, earning credit or ledger entry is created

  @idempotency
  Scenario: Different events describing the same capture are applied once
    When Razorpay sends "payment.captured" for "pay_H01" and later "order.paid" for "order_H01"
    Then "PR-H-01" is "PAID" once
    And downstream effects such as the "Asha paid ₹500" alert happen once

  @idempotency
  Scenario: Webhook and app verification race
    Given the app's verification call and the "payment.captured" webhook for "pay_H01" arrive at the same time
    Then "PR-H-01" becomes "PAID" exactly once

  # ---------- Ordering ----------

  @ordering
  Scenario Outline: Late older events do not overwrite a newer final state
    Given "PR-H-01" is already "<current>" because of "<first_event>"
    When Razorpay delivers an older "<late_event>" for the same payment
    Then "PR-H-01" stays "<current>"

    Examples:
      | current | first_event      | late_event         |
      | PAID    | payment.captured | payment.authorized |
      | PAID    | payment.captured | payment.failed     |

  @ordering
  Scenario: A failed attempt then a successful attempt on the same order
    Given Razorpay sends "payment.failed" for "pay_H01a" on "order_H01"
    When Razorpay sends "payment.captured" for "pay_H01b" on "order_H01"
    Then "PR-H-01" becomes "PAID" with payment "pay_H01b"

  @ordering
  Scenario: Refund processed arrives before refund created
    Given Refund "RF-01" exists with Razorpay Refund "rfnd_01" in status "pending"
    When "refund.processed" for "rfnd_01" arrives before "refund.created"
    Then Refund "RF-01" ends in status "processed"

  # ---------- Delivery failures ----------

  @mock-razorpay @negative
  Scenario: Processing error makes Razorpay retry, and the retry succeeds once
    Given the database is unavailable when "payment.captured" event "evt_002" first arrives
    Then the endpoint responds with a non-2xx status
    When Razorpay retries event "evt_002" after the database recovers
    Then "PR-H-01" becomes "PAID" exactly once

  @negative
  Scenario: Slow processing must not exceed Razorpay's response window
    When Razorpay sends a valid "payment.captured" event
    Then the endpoint acknowledges within 5 seconds
    And heavy follow-up work runs after the acknowledgement

  @negative @mock-razorpay
  Scenario: Endpoint unavailable, recovered by reconciliation
    Given the webhook endpoint is down while "pay_H01" is captured
    When the reconciliation job runs
    Then "PR-H-01" becomes "PAID" from the Razorpay API status
    And a later delivery of the same webhook does not apply it again

  @monitoring @pending-clarification
  Scenario: Razorpay disables the webhook after 24 hours of failures
    Given the webhook has failed continuously for 24 hours
    Then the Proxy Care team is alerted
    And reconciliation keeps payment states correct until the webhook is re-enabled
    # Alert owner and reconciliation schedule are not documented.
