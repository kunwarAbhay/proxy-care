# Traceability: PRD 3.6 step 6 ("amount will be credited to ProxyCare account"), Context §2 payment request status
# The docs do NOT state whether Razorpay auto-capture or manual capture is configured.
# Scenarios are therefore split by @capture-auto / @capture-manual; run only the set matching the
# Proxy Care Razorpay configuration. Authorized and captured are always treated as different states:
# an application record becomes PAID only on a captured payment.
@payments @authorization @capture @api @gateway
Feature: Razorpay payment authorization and capture
  As the Proxy Care backend
  I want to treat authorization and capture as separate gateway states
  So that a payment request is marked paid only when money is actually captured

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a "PAYING" hospital bill payment request "PR-H-01" for ₹500 linked to Razorpay Order "order_H01"

  # ---------- Authorization ----------

  @smoke
  Scenario: Authorized but not yet captured payment is not shown as paid
    Given Razorpay reports payment "pay_H01" for "order_H01" with status "authorized"
    When the backend processes the "payment.authorized" event
    Then "PR-H-01" stays "PAYING"
    And the User sees a processing state, not "₹500 paid"
    And the caretaker does not see "Asha paid ₹500"

  @negative
  Scenario Outline: Authorization fails
    When Razorpay reports payment "pay_H01" as "failed" with error reason "<reason>"
    Then "PR-H-01" becomes "FAILED"
    And the User sees the failure state with "Retry"

    Examples:
      | reason                  |
      | card_declined           |
      | insufficient_fund       |
      | authentication_failed   |
      | payment_timed_out       |
      | gateway_technical_error |

  # ---------- Auto capture ----------

  @capture-auto @smoke
  Scenario: Auto capture moves the request to PAID
    Given Proxy Care orders are created with automatic capture
    When Razorpay captures payment "pay_H01" for 50000 paise
    Then the backend receives "payment.captured" for "pay_H01"
    And "PR-H-01" becomes "PAID" with paidAt, method and the Razorpay Payment ID stored

  @capture-auto @negative @pending-clarification
  Scenario: Authorized payment that Razorpay never auto-captures
    Given Proxy Care orders are created with automatic capture
    And payment "pay_H01" stays "authorized" past Razorpay's auto-capture window
    When Razorpay auto-refunds the uncaptured payment
    Then "PR-H-01" is not "PAID"
    And Asha can pay "PR-H-01" again
    # How the app tells the User about this auto-refund is not documented.

  # ---------- Manual capture ----------

  @capture-manual
  Scenario: Backend captures an authorized payment for the order amount
    Given Proxy Care orders are created with manual capture
    And payment "pay_H01" is "authorized" for 50000 paise
    When the backend captures "pay_H01" for 50000 paise in "INR"
    Then Razorpay reports "pay_H01" as "captured"
    And "PR-H-01" becomes "PAID"

  @capture-manual @negative
  Scenario Outline: Invalid capture requests are refused
    Given Proxy Care orders are created with manual capture
    And payment "<payment>" is in Razorpay status "<rzp_status>" for 50000 paise
    When the backend attempts to capture "<payment>" for <capture_paise> paise
    Then the capture is refused
    And "PR-H-01" does not become "PAID" as a result of this call

    Examples:
      | payment     | rzp_status | capture_paise |
      | pay_H01     | authorized | 60000         |
      | pay_H01     | authorized | 40000         |
      | pay_H01     | failed     | 50000         |
      | pay_UNKNOWN | -          | 50000         |

  @capture-manual @idempotency
  Scenario: Capturing an already captured payment is a no-op for business records
    Given Proxy Care orders are created with manual capture
    And payment "pay_H01" is already "captured" and "PR-H-01" is "PAID"
    When the backend sends another capture for "pay_H01"
    Then Razorpay rejects the duplicate capture
    And "PR-H-01" remains "PAID" with a single Payment record
    And no extra earning, notification or ledger entry is created

  @capture-manual @mock-razorpay @negative
  Scenario: Capture call times out
    Given Proxy Care orders are created with manual capture
    And payment "pay_H01" is "authorized"
    And the Razorpay capture API is stubbed to time out
    When the backend captures "pay_H01"
    Then "PR-H-01" stays "PAYING"
    And the backend later confirms the real Razorpay status of "pay_H01" before retrying
    And at most one capture succeeds

  # ---------- Amount integrity ----------

  @security @negative
  Scenario: Captured amount different from the request amount is not accepted as paid
    Given Razorpay reports payment "pay_H01" as "captured" for 40000 paise on "order_H01"
    When the backend reconciles "pay_H01"
    Then "PR-H-01" is not marked "PAID"
    And the mismatch is raised for manual review
