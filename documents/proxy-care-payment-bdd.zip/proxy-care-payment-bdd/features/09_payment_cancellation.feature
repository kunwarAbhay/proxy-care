# Traceability: PRD 5 (cancellation policy) · Context §1 Cancellation entity, §2 cancellation policy + examples,
#               B4 state "cancelled at gateway", B5 cancel dialog, B1 toast, B7 cancelled chip, §7 booking cancelled
# Refund execution at Razorpay is covered in 13_razorpay_refunds.feature.
# Time zone for all times: Asia/Kolkata. Policy window is measured from "now" to the booking pickup time.
@payments @cancellation
Feature: Cancelling a payment or a paid booking
  As a User
  I want to abandon a payment safely and cancel a paid booking with a clear refund quote
  So that I know exactly what I get back before I confirm

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma" with patient "Ramesh Verma" (WHEELCHAIR)

  # ---------- Cancelled at gateway ----------

  @ui @api @REQ-B4
  Scenario: User cancels at Razorpay Checkout on the booking payment
    Given Asha tapped "Confirm & Pay ₹1,249" and Checkout is open
    When Asha dismisses Checkout without paying
    Then the app shows the cancelled-at-gateway state on the review screen with "Retry"
    And no booking in state "WAITING" exists
    And no refund is created

  # ---------- Cancel dialog quote (B5) ----------

  @ui @api @smoke @REQ-B5
  Scenario Outline: Cancellation quote by time before pickup
    Given booking "PC-2481" is "WAITING", paid ₹1,249, with pickup on 2026-11-02 at 10:00
    And the current time is <now>
    When Asha taps "Cancel booking" on "Finding caretaker"
    Then the dialog shows the pickup date and time and the time remaining
    And the dialog shows policy case "<case>"
    And it shows "You paid ₹1,249", deduction "<deduction>" with its reason, and refund "<refund>"
    And it says the refund goes to the bank account or original payment method in 5-7 working days

    Examples:
      | now              | case          | deduction | refund |
      | 2026-10-31 19:50 | MORE_THAN_8H  | ₹99       | ₹1,150 |
      | 2026-11-02 01:59 | MORE_THAN_8H  | ₹99       | ₹1,150 |
      | 2026-11-02 02:01 | WITHIN_8H     | ₹849      | ₹400   |
      | 2026-11-02 09:30 | WITHIN_8H     | ₹849      | ₹400   |

    @pending-clarification
    Examples: Exactly 8 hours before pickup (behaviour unspecified, Context §9)
      | now              | case          | deduction | refund |
      | 2026-11-02 02:00 | TBD           | TBD       | TBD    |

  @api @REQ-B5
  Scenario Outline: Within-8-hour deduction uses the patient's own 3-hour wage
    Given a "WAITING" booking for a "<mobility>" patient paid ₹<paid>
    And the current time is 3 hours before pickup
    When the backend quotes the cancellation
    Then the deduction is ₹<deduction> and the refund is ₹<refund>

    Examples:
      | mobility   | paid  | deduction | refund |
      | AMBULATORY | 1099  | 699       | 400    |
      | WHEELCHAIR | 1249  | 849       | 400    |
      | BEDRIDDEN  | 1459  | 1059      | 400    |

  @api @REQ-B5
  Scenario: Quote is recalculated at confirm time
    Given booking "PC-2481" pickup is 2026-11-02 10:00
    And Asha opened the cancel dialog at 2026-11-02 01:58 showing a refund of ₹1,150
    When Asha taps "Yes, cancel booking" at 2026-11-02 02:01
    Then the cancellation is recorded with policy case "WITHIN_8H" and refund ₹400
    And Asha is shown the refund amount actually applied

  # ---------- Confirming the cancellation ----------

  @ui @api @smoke @REQ-B5 @REQ-B1
  Scenario: Confirming cancellation cancels the booking and creates a refund
    Given booking "PC-2481" is "WAITING", paid ₹1,249, more than 8 hours before pickup
    When Asha taps "Cancel booking" and then "Yes, cancel booking"
    Then booking "PC-2481" becomes "CANCELLED"
    And a Cancellation is stored with cancelledBy Asha, hoursBeforePickup, policy case, paid ₹1,249, deduction ₹99, refund ₹1,150 and a refund ID
    And a Refund of ₹1,150 with reason "cancellation" is created against the booking's Razorpay payment
    And Asha returns to Home with the toast "Booking cancelled. ₹1,150 will be refunded to your bank"
    And booking "PC-2481" no longer appears under "Upcoming" in My visits
    And under "Past" it shows "Cancelled · ₹1,150 refunded"

  @ui @REQ-B5
  Scenario: Keeping the booking changes nothing
    Given booking "PC-2481" is "WAITING"
    When Asha opens the cancel dialog and taps "Keep booking"
    Then booking "PC-2481" stays "WAITING"
    And no Cancellation or Refund is created

  @api @REQ-CTX7
  Scenario: Cancellation expires pending caretaker requests
    Given booking "PC-2481" is "WAITING" and was sent to 4 caretakers
    When Asha cancels the booking
    Then all 4 pending visit requests expire
    And none of those caretakers can accept the booking

  @api @idempotency
  Scenario: Double confirm creates one cancellation and one refund
    Given booking "PC-2481" is "WAITING"
    When Asha taps "Yes, cancel booking" twice in quick succession
    Then exactly one Cancellation and one Refund exist for "PC-2481"

  @api @negative @pending-clarification
  Scenario: Caretaker accepts at the same moment the User cancels
    Given booking "PC-2481" is "WAITING"
    When caretaker Sunita accepts and Asha confirms cancellation at the same instant
    Then the booking ends in exactly one of "ASSIGNED" or "CANCELLED"
    And a refund exists only if the booking ends "CANCELLED"
    # Cancellation after assignment is not designed (Context §9).

  @api @negative @pending-clarification
  Scenario Outline: Cancellation is not offered outside the designed state
    Given booking "PC-2481" is "<state>"
    Then the User app offers no "Cancel booking" action
    And a direct cancellation API call is refused

    Examples:
      | state       |
      | ASSIGNED    |
      | IN_PROGRESS |
      | COMPLETED   |
      | SETTLED     |
      | CANCELLED   |

  @api @pending-clarification
  Scenario: No-show deducts everything
    Given booking "PC-2481" is assigned and the caretaker reached the pickup on time
    When the visit is recorded as a no-show
    Then the refund is ₹0 and the deduction is ₹1,249
    # How and by whom a no-show is recorded is not designed.
