# Traceability: Context intro (two apps: User, Caretaker), §2 location/visibility rules, P9a "never pays with own
#               money", Entity doc profiles.roles (1-2 roles), booking_secrets (sponsor only)
# Roles in the docs: USER (sponsor) and CARETAKER. Patients have no app access. No admin role is documented.
@payments @access-control @api @security
Feature: Who can see and do what in payments
  As the platform
  I want payment actions restricted to the right role and the right booking
  So that no one can pay, view or change another person's money

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And User "Asha Verma" owns booking "PC-2481" served by caretaker "Sunita Rao"
    And User "Ravi Kumar" owns booking "PC-2490" served by caretaker "Imran Khan"

  @smoke
  Scenario Outline: Payment actions by role
    When <actor> attempts to <action> on booking "PC-2481"
    Then the result is "<result>"

    Examples:
      | actor                 | action                                        | result  |
      | Asha                  | pay a payment request                         | allowed |
      | Asha                  | dispute a hospital bill request               | allowed |
      | Asha                  | cancel the WAITING booking                    | allowed |
      | Asha                  | create a hospital bill payment request        | denied  |
      | Asha                  | attach the hospital's bill                    | denied  |
      | Sunita                | create a hospital bill payment request        | allowed |
      | Sunita                | request a ride fare from the family           | allowed |
      | Sunita                | attach the hospital's bill                    | allowed |
      | Sunita                | pay a payment request                         | denied  |
      | Sunita                | create a caretaker fee request                | denied  |
      | Sunita                | cancel the booking                            | denied  |
      | Imran                 | create a hospital bill payment request        | denied  |
      | Ravi                  | pay a payment request                         | denied  |
      | an unauthenticated client | pay a payment request                     | denied  |

  Scenario Outline: Viewing payment data
    When <actor> requests <data> for booking "PC-2481"
    Then the result is "<result>"

    Examples:
      | actor  | data                                    | result  |
      | Asha   | the Payments tab rows                   | allowed |
      | Asha   | a payment detail with attached bills     | allowed |
      | Asha   | the cancellation quote                  | allowed |
      | Sunita | her visit earning and payout status      | allowed |
      | Sunita | the status of requests she raised        | allowed |
      | Sunita | Asha's payment method and transaction id | denied  |
      | Ravi   | any payment detail                      | denied  |
      | Imran  | Sunita's earnings                       | denied  |

  Scenario: Direct ID guessing returns no data
    When Asha calls the payment detail API with the IDs of Ravi's payments in sequence
    Then every call responds 403 or 404
    And no response reveals amounts, descriptions or existence of those payments

  Scenario: Caretaker can only raise requests on a booking that is in progress and assigned to her
    Given booking "PC-2481" is "ASSIGNED" but the pickup OTP is not yet verified
    When Sunita attempts to create a hospital bill payment request
    Then the request is denied

  Scenario: Requests cannot be raised on a closed booking
    Given booking "PC-2481" is "SETTLED"
    When Sunita attempts to create a ride payment request
    Then the request is denied

  Scenario: Caretaker cannot change the amount of a request after it is sent
    Given Sunita created hospital request "PR-H-01" for ₹500
    When Sunita attempts to edit its amount to ₹900
    Then the change is denied and "PR-H-01" stays ₹500

  @pending-clarification
  Scenario: Same person as User and caretaker on one booking
    Given a profile holds both roles USER and CARETAKER
    When that profile's own booking is offered to it as a caretaker
    Then the expected rule is confirmed by the product owner
    # profiles.roles allows 1-2 roles; self-serving bookings could let one person raise and pay their own requests.

  Scenario: Refund endpoints are not exposed to app roles
    When Asha or Sunita calls a refund creation endpoint
    Then the request is denied
