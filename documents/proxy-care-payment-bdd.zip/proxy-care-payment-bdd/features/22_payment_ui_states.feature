# Traceability: Context §3, §8 (loading, empty, error + retry, disabled CTAs, payment states, uploads),
#               B1, B4, B8, H3, H5, F1, F2
# Responsive behaviour is not documented beyond mobile apps and is not tested here.
@payments @ui-states @ui
Feature: Payment UI states
  As a User or caretaker
  I want every payment screen to show a clear, correct state
  So that I always know what is happening with money

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma" and caretaker "Sunita Rao" on booking "PC-2481"

  Scenario Outline: Pay screen states
    Given Asha is on "<screen>"
    When the payment is in state "<state>"
    Then the screen shows "<display>"
    And the pay button is "<button>"

    Examples:
      | screen                   | state                       | display                               | button   |
      | Hospital payment request | requested                   | amount, description, Approve & Pay    | enabled  |
      | Hospital payment request | redirecting                 | Opening secure payment                | disabled |
      | Hospital payment request | waiting for backend result  | processing                            | disabled |
      | Hospital payment request | paid                        | ₹500 paid                             | hidden   |
      | Hospital payment request | failed                      | failure with Retry                    | enabled  |
      | Hospital payment request | disputed                    | disputed                              | hidden   |
      | Final caretaker bill     | open                        | Pay Caretaker ₹250                    | enabled  |
      | Final caretaker bill     | redirecting                 | Opening secure payment                | disabled |
      | Final caretaker bill     | settled                     | settled                               | hidden   |
      | Final caretaker bill     | payment failed              | failure with Retry                    | enabled  |

  Scenario: Loading skeleton on the Payments tab
    Given the payments list request is slow
    When Asha opens the Payments tab
    Then a loading skeleton is shown until the list arrives

  Scenario: Error with retry on the Payments tab
    Given the payments list request fails
    When Asha opens the Payments tab
    Then an error with "Retry" is shown
    When the request succeeds on retry
    Then the list is shown

  Scenario Outline: Empty states
    Given <condition>
    When Asha opens <screen>
    Then the empty state for <area> is shown

    Examples:
      | condition                        | screen      | area                      |
      | Asha has no pending requests     | Home        | pending payment requests  |
      | Asha has no ongoing visit        | Home        | ongoing visit             |
      | Asha has paid nothing            | Payments    | payments                  |

  Scenario Outline: Caretaker bill status screen states
    Given the hospital bill for ₹500 is "<status>"
    When Sunita opens Bill status
    Then it shows "<banner>"
    And the primary action is "<action>"

    Examples:
      | status            | banner                                       | action                  |
      | PAYMENT_REQUESTED | waiting for family                           | Remind family           |
      | PAID_BILL_PENDING | paid · attach hospital bill                  | Attach hospital bill    |
      | BILL_ATTACHED     | Hospital bill attached · shared with Asha    | View hospital bill      |
      | QR_MISMATCH       | QR mismatch, no request sent                 | Scan again              |

  Scenario Outline: Upload states for the hospital bill
    Given Sunita is attaching the hospital's bill
    When the upload <event>
    Then the screen shows <display>

    Examples:
      | event                 | display                                        |
      | is in progress        | upload progress and a disabled share button     |
      | fails                 | an upload error with retry                      |
      | is larger than allowed | a file too large message                       |

  Scenario: Session expired during payment
    Given Asha's session expires while Razorpay Checkout is open
    When Asha completes the payment and returns to the app
    Then Asha is asked to sign in again
    And after sign-in the request shows the backend status

  Scenario: Offline when tapping Approve & Pay
    Given the device is offline
    When Asha taps "Approve & Pay"
    Then an error with "Retry" is shown and no Checkout opens

  Scenario Outline: Final bill net states
    Given the final bill net is "<net>"
    Then the F1 primary action is "<action>"

    Examples:
      | net            | action                     |
      | to pay ₹250    | Pay Caretaker ₹250         |
      | refund ₹375    | Close visit & get ₹375 back |
      | ₹0             | Approve & close visit      |
