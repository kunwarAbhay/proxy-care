# Traceability: Critical instructions (backend verification, no secret exposure), Context §1 Aadhaar masked /
#               bank masked, Entity doc booking_secrets, webhook_events payload storage
# Most checks are static or log/traffic inspections (@static-check) plus API tests.
@payments @security
Feature: Payment security controls
  As the platform
  I want secrets, card data and amounts protected end to end
  So that payments cannot be forged, leaked or redirected

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode

  @static-check @smoke
  Scenario: Razorpay Key Secret and webhook secret never reach the apps
    When the User app and Caretaker app release builds are inspected
    And all API responses captured during a full payment journey are inspected
    Then neither the Razorpay Key Secret nor the webhook secret appears anywhere
    And only the Razorpay Key ID is present in the User app

  @static-check
  Scenario: Live keys are not used outside production
    When the test environment configuration is inspected
    Then the Razorpay Key ID starts with "rzp_test_"

  @api
  Scenario Outline: Sensitive data never appears in logs or stored records
    Given a full payment journey has been run with card "4100 2800 0000 1007", CVV "123" and UPI ID "success@razorpay"
    When application logs, error reports and database tables are searched for "<sensitive>"
    Then no match is found

    Examples:
      | sensitive                  |
      | 4100280000001007           |
      | the CVV value               |
      | the card expiry             |
      | the Razorpay Key Secret     |
      | the webhook secret          |
      | full bank account numbers   |
      | the 4-digit pickup code     |

  @api
  Scenario: Stored webhook payloads hold no full card data
    When a "payment.captured" webhook for a card payment is stored
    Then the stored payload has no full card number or CVV

  @api
  Scenario: All payment traffic uses HTTPS
    When the apps call payment endpoints and Razorpay calls the webhook endpoint
    Then every call uses HTTPS
    And plain HTTP requests to payment endpoints are refused

  @api
  Scenario Outline: Amounts and currency come only from trusted backend data
    When the app sends <tampered_field> in a payment call
    Then the backend uses its stored value
    And the Razorpay Order matches the stored amount and "INR"

    Examples:
      | tampered_field                       |
      | an amount lower than the request     |
      | currency "USD"                       |
      | a different booking ID               |
      | a different payee                    |

  @api
  Scenario: The client success callback alone never marks a payment paid
    When the app reports success without a verifiable Razorpay signature
    Then no payment request, booking or earning changes state

  @api
  Scenario: Hospital QR payload cannot be swapped after verification
    Given a hospital QR passed all checks for "Apollo Hospital, Bannerghatta"
    When the caretaker app submits a different QR payload with the verified flag set
    Then the backend re-checks the payload and treats it as unverified

  @api
  Scenario: Verification and payment endpoints are rate limited
    When one session sends many verification calls with random signatures in a short time
    Then further calls are throttled
    And no payment changes state

  @api @pending-clarification
  Scenario: Pickup code is never exposed to the caretaker app
    When the caretaker app loads booking "PC-2481"
    Then the pickup code is absent from every response
    # Included because booking_secrets is in the payment-adjacent schema; billable time starts at OTP verification.

  @api @pending-clarification
  Scenario: Hospital money reaches the hospital's verified UPI handle only
    Given the User paid ₹500 for a hospital bill whose QR payee is "apollo.blr@upi"
    Then any onward disbursement goes only to "apollo.blr@upi"
    # How Proxy Care pays the hospital and ride partner after collecting the money is not documented.
