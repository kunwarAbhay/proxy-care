# Traceability: Context §3 steps 1-3 ("Opening secure payment" sheet -> gateway page -> return), §8 payment states
# Note: the docs say the app "redirects to the gateway page" in a mobile app. Whether this is the Razorpay
# Android/iOS Checkout SDK, a web Checkout in a browser tab, or a Payment Link is not documented
# (@pending-clarification). Steps below are written against the observable behaviour so they work for any of these.
@payments @checkout @ui @gateway
Feature: Razorpay Checkout session from open to return
  As a User
  I want a reliable hand-off to Razorpay and back
  So that I always land on the right result screen

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma" with verified mobile "+919800000001"
    And a "REQUESTED" hospital bill payment request "PR-H-01" for ₹500 on booking "PC-2481"

  @smoke
  Scenario: Checkout opens with the correct order details
    When Asha taps "Approve & Pay" on "PR-H-01"
    Then the "Opening secure payment" sheet is shown
    And Razorpay Checkout opens with the Razorpay Order ID for "PR-H-01"
    And Checkout shows the amount "₹500"
    And Checkout shows the merchant name configured for Proxy Care
    And Checkout prefills the contact "+919800000001"

  Scenario: Checkout amount matches the backend order exactly
    When Asha taps "Approve & Pay" on "PR-H-01"
    Then the amount shown in Checkout equals the Razorpay Order amount 50000 paise
    And the currency shown is INR

  @smoke
  Scenario: Successful return from Checkout
    Given Razorpay Checkout is open for "PR-H-01"
    When Asha completes the payment with UPI ID "success@razorpay"
    Then the app receives razorpay_payment_id, razorpay_order_id and razorpay_signature
    And the app sends them to the backend for verification
    And only after the backend confirms does the app show "₹500 paid" with "Continue"

  Scenario Outline: User leaves Checkout without paying
    Given Razorpay Checkout is open for "PR-H-01"
    When Asha <leave_action>
    Then the app returns to the hospital payment request screen
    And the app shows that the payment was not completed with "Retry"
    And "PR-H-01" is still payable
    And no "₹500 paid" state is shown

    Examples:
      | leave_action                                  |
      | closes Checkout with the close control        |
      | presses the device back button in Checkout     |
      | selects "Failure" on the mock net banking page |

  @mock-razorpay @negative
  Scenario: Checkout fails to initialise
    Given the Razorpay Checkout library is stubbed to fail on load
    When Asha taps "Approve & Pay" on "PR-H-01"
    Then the "Opening secure payment" sheet is replaced by an error with "Retry"
    And "PR-H-01" is still payable

  @mock-razorpay @negative
  Scenario Outline: Invalid Checkout configuration
    Given Checkout is configured with <bad_config>
    When Asha taps "Approve & Pay" on "PR-H-01"
    Then Checkout does not take a payment
    And the app shows the payment failure state with "Retry"
    And the error is reported to monitoring

    Examples:
      | bad_config                        |
      | an incorrect Razorpay Key ID       |
      | a missing order_id option          |
      | an order_id from another account   |
      | a missing amount option            |

  @negative
  Scenario: Network drops while Checkout is open and the payment had already succeeded
    Given Razorpay Checkout is open for "PR-H-01"
    And Asha completes a UPI payment that Razorpay captures
    And the device loses network before the app receives the Checkout response
    When the network returns and Asha reopens the app
    Then the app polls the backend for the status of "PR-H-01"
    And the backend status comes from Razorpay webhook or Razorpay API reconciliation
    And the app shows "₹500 paid"

  @negative
  Scenario: Network drops while Checkout is open and nothing was paid
    Given Razorpay Checkout is open for "PR-H-01"
    And the device loses network before Asha submits a payment
    When the network returns and Asha reopens the app
    Then the app shows that the payment was not completed with "Retry"
    And "PR-H-01" is still payable

  Scenario: App killed during Checkout and reopened
    Given Razorpay Checkout is open for "PR-H-01" and "PR-H-01" is "PAYING"
    When the app process is killed and Asha relaunches the app
    Then the app checks the status of "PR-H-01" with the backend
    And shows the result that matches the backend status

  Scenario: Only one Checkout can be open at a time
    Given Razorpay Checkout is already open for "PR-H-01"
    When the app receives another tap on "Approve & Pay"
    Then no second Checkout is opened

  @pending-clarification
  Scenario: Checkout session left idle until Razorpay times it out
    Given Razorpay Checkout is open for "PR-H-01"
    When Asha leaves Checkout idle until Razorpay ends the session
    Then the app shows that the payment was not completed with "Retry"
    And "PR-H-01" is still payable
    # Checkout timeout value is not configured in the docs.
