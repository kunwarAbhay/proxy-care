# Traceability: B4 (policy checkbox), H2 / H2a (QR checks, amount, description), H4 (attach bill)
# Entity doc: hospital_bills.amount_paise > 0, description <= 200 chars
# These are the Proxy Care-owned inputs that decide what gets charged. Razorpay Checkout field
# validation lives in 02_payment_methods.feature.
@payments @validation
Feature: Proxy Care form validation that governs what is charged
  As the platform
  I want amounts and consents validated before any Razorpay Order exists
  So that Users are only ever asked to pay valid, explained charges

  # ---------- B4 consent ----------

  @ui @REQ-B4
  Scenario: Confirm & Pay is disabled until the cancellation policy is acknowledged
    Given a signed-in User "Asha Verma" on the "Review · Confirm & Pay" screen for a ₹1,249 booking
    And the checkbox "I've read the cancellation policy" is not ticked
    Then the "Confirm & Pay ₹1,249" button is disabled
    When Asha ticks the checkbox
    Then the "Confirm & Pay ₹1,249" button is enabled
    When Asha unticks the checkbox
    Then the "Confirm & Pay ₹1,249" button is disabled

  @api @REQ-B4 @security
  Scenario: Backend rejects a booking payment without policy acknowledgement
    Given a signed-in User "Asha Verma" with a complete booking draft
    When the app calls the booking payment endpoint without the policy acknowledgement
    Then the backend responds with a validation error
    And no Razorpay Order is created

  # ---------- H2 QR checks ----------

  @ui @api @REQ-H2
  Scenario Outline: QR checks decide whether a hospital payment request can be raised
    Given caretaker "Sunita Rao" is on the hospital to-do screen for booking "PC-2481" at "Apollo Hospital, Bannerghatta"
    When Sunita scans a UPI QR with merchant name "<merchant>" and MCC "<mcc>"
    Then the QR check results are readable "<readable>", merchant matches "<name_ok>", MCC is hospital "<mcc_ok>"
    And Sunita is taken to "<next_screen>"

    Examples:
      | merchant                       | mcc  | readable | name_ok | mcc_ok | next_screen                       |
      | Apollo Hospital Bannerghatta   | 8062 | yes      | yes     | yes    | Payment request details           |
      | Sri Lakshmi Medicals           | 8062 | yes      | no      | yes    | Bill status with QR mismatch      |
      | Apollo Hospital Bannerghatta   | 5411 | yes      | yes     | no     | Bill status with QR mismatch      |

  @ui @api @negative @REQ-H2
  Scenario: Non-UPI QR is rejected and no request is sent
    Given caretaker "Sunita Rao" is scanning a hospital bill QR for booking "PC-2481"
    When Sunita scans a QR that is not a UPI payment QR
    Then the bill status shows "QR mismatch" with "Scan again"
    And no payment request is sent to the User

  @ui @REQ-H2
  Scenario: There is no photo-upload fallback on the scan screen
    Given caretaker "Sunita Rao" is on the "Scan bill QR" screen
    Then only the camera viewfinder and torch are offered
    And there is no option to upload a bill photo instead of scanning

  # ---------- H2a amount and description ----------

  @ui @REQ-H2a
  Scenario: Amount from the QR is read-only
    Given caretaker "Sunita Rao" scanned a verified hospital QR carrying amount "500.00"
    When the "Payment request details" screen opens
    Then "Amount in the QR" shows "₹500" and cannot be edited

  @ui @REQ-H2a
  Scenario Outline: Amount must be typed when the QR has no amount
    Given caretaker "Sunita Rao" scanned a verified hospital QR without an amount
    And the screen notes that the QR has no amount
    When Sunita enters amount "<amount>" and description "Consultation fee"
    Then the "Send to family" button is "<button_state>"
    And an inline validation message on the amount field is "<inline_error>"
    # Exact copy for amount errors is not documented; assert presence only.

    Examples:
      | amount  | button_state | inline_error |
      | 500     | enabled      | absent       |
      | 1       | enabled      | absent       |
      |         | disabled     | absent       |
      | 0       | disabled     | present      |
      | -50     | disabled     | present      |
      | abc     | disabled     | present      |

  @ui @REQ-H2a
  Scenario Outline: Description is mandatory and limited to 200 characters
    Given caretaker "Sunita Rao" is on "Payment request details" with a valid amount
    When Sunita enters a description of <length> characters
    Then the "Send to family" button is "<button_state>"

    Examples:
      | length | button_state |
      | 0      | disabled     |
      | 1      | enabled      |
      | 200    | enabled      |
      | 201    | disabled     |

  @ui @REQ-H2a
  Scenario Outline: Quick chips fill the description
    Given caretaker "Sunita Rao" is on "Payment request details"
    When Sunita taps the quick chip "<chip>"
    Then the description field contains "<chip>"

    Examples:
      | chip             |
      | Consultation fee |
      | Lab test         |
      | Medicines        |

  @api @security @REQ-H2a
  Scenario: Backend ignores a typed amount when the QR carries an amount
    Given a verified hospital QR payload with amount "500.00"
    When the caretaker app submits the hospital bill with amount ₹900
    Then the backend creates the hospital bill with amount ₹500 and amount source "QR"
    And the payment request amount is ₹500

  @api @REQ-H2a
  Scenario: Typed amount is stored with amount source MANUAL
    Given a verified hospital QR payload without an amount
    When the caretaker submits amount ₹750 and description "Lab test"
    Then the hospital bill has amount ₹750 and amount source "MANUAL"
    And a "HOSPITAL_BILL" payment request for ₹750 with description "Lab test" is created

  @api @negative @security @REQ-H2
  Scenario: Backend re-runs QR checks and refuses a mismatched QR
    Given a QR payload whose merchant name does not match the booking's hospital
    When the caretaker app submits the hospital bill directly to the backend
    Then the backend records the hospital bill with status "QR_MISMATCH"
    And no payment request is created

  # ---------- H4 attach bill ----------

  @ui @REQ-H4
  Scenario: Attach & share is disabled until a file is added
    Given the hospital bill for ₹500 on booking "PC-2481" is "PAID_BILL_PENDING"
    When caretaker "Sunita Rao" opens "Attach hospital bill"
    Then the "Attach & share with Asha" button is disabled
    When Sunita takes a photo of the bill
    Then a preview is shown with "Retake" and "Replace"
    And the "Attach & share with Asha" button is enabled

  @ui @pending-clarification @REQ-H4
  Scenario Outline: Bill file type and size limits on H4
    Given the hospital bill is "PAID_BILL_PENDING"
    When caretaker "Sunita Rao" uploads a "<type>" file of <size_mb> MB
    Then the upload result is "<result>"
    # H4 limits are an open point (Context §9). Rows mirror the booking attachment limits (JPG/PNG/PDF, <= 10 MB) as an assumption.

    Examples:
      | type | size_mb | result   |
      | JPG  | 2       | accepted |
      | PDF  | 10      | accepted |
      | PDF  | 11      | rejected |
      | DOCX | 1       | rejected |
