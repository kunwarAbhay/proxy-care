# Traceability: PRD 3.1, 3.2, 3.4, 3.5, 3.6 · Context §1 (Payment request, Payment), §3 shared payment pattern,
#               screens B4, U2b, U3b, H5, F1, F2
# Layer tags: @ui = app screen, @api = Proxy Care backend, @gateway = Razorpay (test mode)
@payments @initiation
Feature: Payment initiation for the booking charge and for payment requests
  As a User sponsoring a hospital visit
  I want every charge to open a Razorpay payment for the exact amount the backend holds
  So that I pay the right payee the right amount without a wallet

  The booking charge is paid on B4 ("Confirm & Pay"). Every later charge (ride to hospital, ride home,
  hospital bill, caretaker fee) arrives as a payment request paid with "Approve & Pay" (shared pattern §3).
  All amounts are INR and are sent to Razorpay in paise.

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma" with verified mobile "+919800000001"
    And Asha has a linked patient "Ramesh Verma" with relation "Father", age 72 and mobility "WHEELCHAIR"

  # ---------- Booking charge (B4) ----------

  @ui @api @smoke @REQ-B4
  Scenario Outline: Review screen shows the booking price for the patient's mobility category
    Given Asha has a linked patient "Test Patient" with mobility "<mobility>"
    And Asha has completed booking steps B2 and B3 for "Test Patient"
    When Asha opens the "Review · Confirm & Pay" screen
    Then the price breakdown shows caretaker wage "<wage_line>", margin "₹400" and platform fee "₹99"
    And the total shows "<total>"
    And the primary button reads "Confirm & Pay <total>"
    And a note says rides and hospital bills will arrive later as payment requests
    And the cancellation policy shows the refund for each cancellation case

    Examples:
      | mobility   | wage_line      | total  |
      | AMBULATORY | ₹200 × 3 h     | ₹1,099 |
      | WHEELCHAIR | ₹250 × 3 h     | ₹1,249 |
      | BEDRIDDEN  | ₹320 × 3 h     | ₹1,459 |

  @ui @api @gateway @smoke @REQ-B4 @REQ-CTX3
  Scenario: Successful booking payment end to end
    Given Asha is on the "Review · Confirm & Pay" screen for a WHEELCHAIR visit priced ₹1,249
    And Asha has ticked "I've read the cancellation policy"
    When Asha taps "Confirm & Pay ₹1,249"
    Then the "Opening secure payment" sheet is shown
    And the backend creates a Razorpay Order for 124900 paise in currency "INR"
    And Razorpay Checkout opens with that Razorpay Order ID
    When Asha pays with the Razorpay test UPI ID "success@razorpay"
    And the backend verifies the Razorpay payment signature
    Then the success state "₹1,249 paid" is shown with a "Continue" button
    And a booking is created with state "WAITING" and a code matching "PC-\d+"
    When Asha taps "Continue"
    Then the "Finding caretaker" screen shows the booking code, "₹1,249 paid" and a receipt link

  @api @REQ-B4
  Scenario: Price used for the Razorpay Order comes from backend pricing rules, not from the app
    Given the pricing rule for "WHEELCHAIR" is wage ₹250 per hour, 3 block hours, margin ₹400 and fee ₹99
    When the app requests a booking payment and sends a client-side amount of ₹1
    Then the backend creates the Razorpay Order for 124900 paise
    And the booking stores a price snapshot of wage 25000, block 3, margin 40000 and fee 9900 paise

  @api @REQ-B4
  Scenario: Booking price snapshot is frozen at confirm time
    Given Asha has opened the payment for a WHEELCHAIR booking priced ₹1,249
    When an operator changes the WHEELCHAIR hourly wage to ₹280 before Asha completes payment
    And Asha completes payment for the existing Razorpay Order
    Then the booking keeps the price snapshot of ₹1,249
    And the booking's later fee calculation uses the snapshot wage of ₹250 per hour

  # ---------- Payment requests (shared pattern §3) ----------

  @ui @api @gateway @smoke @REQ-CTX3
  Scenario Outline: Approve & Pay for each payment request type
    Given booking "PC-2481" for patient "Ramesh Verma" is "IN_PROGRESS"
    And a payment request of type "<type>" for ₹<amount> with description "<description>" and payee "<payee>" is "REQUESTED"
    When Asha opens the request from "<entry_point>"
    Then the "<screen>" screen shows the amount "₹<amount>", the description and the payee
    When Asha taps "Approve & Pay"
    Then the backend creates a Razorpay Order for <paise> paise in "INR" linked to that payment request
    And Razorpay Checkout opens with that Razorpay Order ID
    When Asha completes the payment with a Razorpay test success fixture
    And the backend verifies the payment
    Then the payment request status becomes "PAID"
    And the app shows "₹<amount> paid" with a "Continue" button

    Examples:
      | type             | amount | paise | description                         | payee              | entry_point                 | screen                  |
      | RIDE_TO_HOSPITAL | 286    | 28600 | Cab to Apollo Hospital, Bannerghatta | Ride partner       | ride payment banner on U2   | Ride payment request    |
      | HOSPITAL_BILL    | 500    | 50000 | OPD registration + consultation fee  | Apollo Hospital    | hospital payment banner     | Hospital payment request |
      | RIDE_HOME        | 312    | 31200 | Cab home from Apollo Hospital        | Ride partner       | ride-home banner on U3      | Ride home payment request |
      | CARETAKER_FEE    | 250    | 25000 | Extra time · 1 h                     | Proxy Care         | Review final bill on U4     | Final caretaker bill    |

  @ui @REQ-B1
  Scenario: Pending payment requests are listed on Home with a count
    Given Asha has 2 payment requests in status "REQUESTED" and 1 in status "FAILED"
    And Asha has 1 payment request in status "PAID"
    When Asha opens Home
    Then the "Pending payment requests" list shows 3 items with a count badge of 3
    And each item shows description, payee, requested-by, time and amount
    And the "PAID" request is not listed

  @ui @REQ-B1
  Scenario Outline: Tapping a pending request on Home opens the matching pay screen
    Given Asha has a "REQUESTED" payment request of type "<type>"
    When Asha taps it in the "Pending payment requests" list on Home
    Then the "<screen>" screen opens for that request

    Examples:
      | type             | screen                     |
      | HOSPITAL_BILL    | Hospital payment request   |
      | RIDE_TO_HOSPITAL | Ride payment request       |
      | RIDE_HOME        | Ride home payment request  |

  @ui @REQ-H5
  Scenario: Hospital payment request shows QR checks and no bill image
    Given a "REQUESTED" hospital bill payment request for ₹500 created by caretaker "Sunita" at 11:05
    When Asha opens the hospital payment request
    Then the screen shows the description, "₹500", "Requested by Sunita · 11:05"
    And it shows that the QR checks passed with the hospital name and MCC "8062"
    And it shows the note that the hospital desk is waiting
    And no bill image is shown

  @ui @REQ-U2b
  Scenario: Ride payment request shows trip details
    Given a "REQUESTED" ride payment request for the leg "TO_HOSPITAL" with final fare ₹286
    When Asha opens the ride payment request
    Then the screen shows "₹286", a status chip, the ride, the trip route, the trip time and the driver name
    And it offers "Approve & Pay" and "Call caretaker"

  @api @REQ-CTX1
  Scenario: Ride payment request amount is the ride partner's final fare
    Given the ride for leg "TO_HOSPITAL" has a fare estimate of ₹270 and a final fare of ₹286
    When caretaker Sunita taps "Request ₹286 from family"
    Then a "RIDE_TO_HOSPITAL" payment request is created for ₹286
    And the request amount cannot be changed by the caretaker
