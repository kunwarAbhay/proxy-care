# Traceability: Context §3 "API needs: create gateway order for a booking or payment request · idempotency on
#               repeat taps", §1 Payment (gateway session/order id), Entity doc webhook_events (RAZORPAY)
# Most scenarios need a Razorpay API stub (@mock-razorpay) to force error responses deterministically.
@payments @orders @api
Feature: Razorpay Order creation and mapping
  As the Proxy Care backend
  I want to create exactly one valid Razorpay Order per payable item
  So that every Checkout session is bound to a trusted amount, currency and business record

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma" with verified mobile "+919800000001"

  @gateway @smoke
  Scenario: Order for the booking charge
    Given Asha has a complete WHEELCHAIR booking draft priced ₹1,249 with the policy acknowledged
    When Asha requests to pay the booking charge
    Then a Razorpay Order is created with amount 124900, currency "INR" and status "created"
    And a Payment record is stored with the Razorpay Order ID, amount 124900, an unpaid status and no payment request ID
    And the response to the app contains the Razorpay Order ID, amount 124900, currency "INR" and the Razorpay Key ID
    And the response does not contain the Razorpay Key Secret

  @gateway @smoke
  Scenario: Order for a payment request
    Given a "REQUESTED" hospital bill payment request "PR-H-01" for ₹500 on booking "PC-2481" belonging to Asha
    When Asha requests to pay "PR-H-01"
    Then a Razorpay Order is created with amount 50000 and currency "INR"
    And a Payment record links the Razorpay Order ID to booking "PC-2481" and payment request "PR-H-01"
    And the payment request status becomes "PAYING"

  Scenario: Razorpay Order carries Proxy Care references for reconciliation
    Given a "REQUESTED" payment request "PR-R-01" on booking "PC-2481"
    When the backend creates the Razorpay Order for "PR-R-01"
    Then the order receipt or notes identify booking "PC-2481" and payment request "PR-R-01"
    And the order receipt is unique across all Proxy Care orders

  Scenario: Order amount comes from the stored payment request, not the request body
    Given a "REQUESTED" payment request "PR-H-01" for ₹500
    When the app requests to pay "PR-H-01" and includes an amount of ₹5
    Then the Razorpay Order is created for 50000 paise
    And the client-supplied amount is ignored

  Scenario Outline: Invalid order inputs are rejected before calling Razorpay
    Given a payable item whose stored amount is <paise> paise and currency "<currency>"
    When the backend attempts to create the Razorpay Order
    Then no call is made to Razorpay
    And the app receives an error and the Pay button becomes available again
    And the item stays payable

    Examples:
      | paise | currency |
      | 0     | INR      |
      | -100  | INR      |
      | 99    | INR      |
      | 50000 |          |
      | 50000 | USD      |

  Scenario Outline: Items that are not payable cannot get an order
    Given payment request "PR-X" has status "<status>"
    When Asha requests to pay "PR-X"
    Then the backend responds with a conflict error
    And no Razorpay Order is created

    Examples:
      | status   |
      | PAID     |
      | DISPUTED |

  Scenario: No order for a hospital bill that failed the QR checks
    Given a hospital bill with status "QR_MISMATCH" on booking "PC-2481"
    Then no payment request exists for that hospital bill
    And no Razorpay Order can be created for it

  @mock-razorpay @negative
  Scenario Outline: Razorpay errors during order creation
    Given the Razorpay Orders API is stubbed to respond with "<response>"
    And a "REQUESTED" payment request "PR-H-01" for ₹500
    When Asha taps "Approve & Pay" for "PR-H-01"
    Then the app shows the payment failure state with "Retry"
    And no Checkout is opened
    And payment request "PR-H-01" is still payable
    And the failure is logged without card, UPI or secret data

    Examples:
      | response                                  |
      | HTTP 400 BAD_REQUEST_ERROR                |
      | HTTP 401 authentication failed            |
      | HTTP 500 SERVER_ERROR                     |
      | HTTP 503 service unavailable              |
      | no response within the client timeout     |
      | HTTP 200 with a body missing the order id |

  @mock-razorpay @negative
  Scenario: Proxy Care backend failure while creating the order
    Given the Proxy Care payment service returns HTTP 500 when creating an order
    When Asha taps "Confirm & Pay ₹1,249"
    Then the app shows an error with "Retry"
    And no booking in state "WAITING" is created

  @idempotency
  Scenario: Repeat taps reuse one open order
    Given a "REQUESTED" payment request "PR-H-01" for ₹500
    When Asha taps "Approve & Pay" for "PR-H-01" 3 times within 2 seconds
    Then exactly one Razorpay Order exists for "PR-H-01"
    And every response returns the same Razorpay Order ID

  @idempotency @pending-clarification
  Scenario: Retry after a failed attempt reuses or replaces the order without double charging
    Given payment request "PR-H-01" has status "FAILED" with Razorpay Order "order_A" in status "attempted"
    When Asha taps "Approve & Pay" again
    Then Checkout opens for an order of 50000 paise linked to "PR-H-01"
    And at most one captured Razorpay payment can be linked to "PR-H-01"
    # Whether the retry reuses order_A or creates a new order is not documented.

  @negative
  Scenario: Checkout cannot be opened without a Razorpay Order ID
    Given the order creation response did not contain a Razorpay Order ID
    When the app tries to open Razorpay Checkout
    Then Checkout is not opened
    And the app shows the payment failure state with "Retry"

  @negative @security
  Scenario: Verification is refused when the Razorpay Order ID does not belong to the item
    Given payment request "PR-H-01" is linked to Razorpay Order "order_A"
    When a verification call for "PR-H-01" arrives with Razorpay Order "order_B"
    Then the backend rejects the verification
    And "PR-H-01" is not marked "PAID"

  @negative @pending-clarification
  Scenario: Expired or stale order
    Given Razorpay Order "order_A" for payment request "PR-H-01" was created more than the configured order validity ago
    When Asha taps "Approve & Pay"
    Then a payable Razorpay Order is presented for "PR-H-01"
    And the stale order cannot produce a second captured payment
    # Order validity / expiry window is not documented.
