# Traceability: Context §7 realtime events / notifications, B1 toast, Entity doc device_tokens (FCM push)
# Supported channels in the docs: in-app realtime banners/alerts, toasts, and push (FCM device tokens).
# Email and SMS payment notifications are NOT documented (SMS is only used for OTP and the pickup code),
# so they are not tested here; see the gaps report.
@payments @notifications
Feature: Payment notifications to the User and the caretaker
  As a User or caretaker
  I want timely, correct alerts about payment requests and their outcomes
  So that the visit never stalls waiting on a payment

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma" and caretaker "Sunita Rao" on booking "PC-2481"

  @ui @smoke
  Scenario Outline: New payment request alerts the User with a banner that opens the pay screen
    Given Asha is on "<current_screen>"
    When a "<type>" payment request for ₹<amount> is created
    Then Asha sees a banner for the ₹<amount> request
    And tapping the banner opens "<pay_screen>"
    And the request appears in the Home pending list

    Examples:
      | current_screen   | type             | amount | pay_screen                 |
      | Visit timeline   | RIDE_TO_HOSPITAL | 286    | Ride payment request       |
      | Services status  | HOSPITAL_BILL    | 500    | Hospital payment request   |
      | Coming home      | RIDE_HOME        | 312    | Ride home payment request  |
      | Visit completed  | CARETAKER_FEE    | 250    | Final caretaker bill       |

  @ui @smoke
  Scenario Outline: Paid or failed request updates the caretaker
    Given a "<type>" request for ₹<amount> is "PAYING"
    When the payment is <outcome>
    Then Sunita's "<screen>" shows "<message>"

    Examples:
      | type             | amount | outcome   | screen       | message                     |
      | RIDE_TO_HOSPITAL | 286    | verified  | Ride payment | Asha paid                   |
      | HOSPITAL_BILL    | 500    | verified  | Bill status  | Asha paid ₹500              |
      | HOSPITAL_BILL    | 500    | failed    | Bill status  | waiting for family          |

  @ui
  Scenario: Hospital bill attached notifies the User
    Given the hospital bill for ₹500 is "PAID_BILL_PENDING"
    When Sunita attaches the hospital's bill
    Then Asha's payment details for that request show the bill in the Bills section

  @ui
  Scenario: Caretaker fee paid updates the caretaker's wallet in real time
    When Asha's caretaker fee payment is verified
    Then Sunita's visit earnings and earnings chip update without a manual refresh

  @ui @payout @pending-clarification
  Scenario: Withdrawal processed notifies the caretaker
    When Sunita's withdrawal is processed
    Then visit earnings shows withdrawn with bank and UTR

  @ui
  Scenario: Settlement reminder to the User
    Given Sunita's earning is "ON_HOLD" because "PR-H-01" is unpaid
    When Sunita taps "Notify family"
    Then Asha's unpaid requests screen shows the caretaker reminder message

  @ui
  Scenario: Cancellation toast shows the refund amount
    When Asha cancels "PC-2481" for a refund of ₹1,150
    Then Home shows the toast "Booking cancelled. ₹1,150 will be refunded to your bank"

  @api
  Scenario: Push is sent when the app is in the background
    Given Asha's app is in the background with a registered FCM token
    When a hospital payment request for ₹500 is created
    Then a push notification is sent to Asha's device token
    And opening it lands on the hospital payment request screen

  @api @negative
  Scenario: Push delivery failure does not lose the request
    Given Asha's FCM token is invalid
    When a hospital payment request for ₹500 is created
    Then the push failure is logged
    And the request still appears in the Home pending list when Asha opens the app

  @api @idempotency
  Scenario: Duplicate webhook does not send duplicate notifications
    Given the "payment.captured" event for "PR-H-01" is delivered twice
    Then Sunita receives the "Asha paid ₹500" alert once

  @api
  Scenario: Notification amounts match the backend record
    Given payment request "PR-H-01" is stored as ₹500 with description "OPD registration + consultation fee"
    When its notification is sent
    Then the notification amount and description match the stored request exactly

  @security
  Scenario: Notifications carry no sensitive payment data
    When any payment notification is sent
    Then it contains no card number, CVV, UPI PIN, signature or Razorpay secret
