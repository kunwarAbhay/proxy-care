# Traceability: PRD 3.6, 3.7, 4.1 · Context §2 final fee strategy (PROPOSED), settlement order, caretaker earning
#               status, screens D5, U4, F2, F1, F3, F4, F5, P1 wallet chip
# Caretaker withdrawals are assumed to use RazorpayX payouts (Entity doc: razorpayx_contact_id,
# razorpayx_fund_account_id, webhook provider RAZORPAYX). The UI's manual "Withdraw to bank" is an assumption
# per Context §9, so withdrawal scenarios are tagged @pending-clarification.
@payments @settlement
Feature: Final settlement, caretaker fee and caretaker earnings
  As the platform
  I want to settle a visit only after every charge is paid
  So that the caretaker is paid correctly and the User pays only for time actually used

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma" with patient "Ramesh Verma" (WHEELCHAIR, ₹250 per hour)
    And caretaker "Sunita Rao" is assigned to booking "PC-2481" paid ₹1,249 at booking

  # ---------- Settlement audit ----------

  @ui @api @smoke @REQ-F2
  Scenario: Unpaid requests block closing the visit
    Given hospital bill payment request "PR-H-01" for ₹500 is "REQUESTED"
    When Sunita marks "Visit Completed" after ticking all handover checklist items
    Then booking "PC-2481" becomes "COMPLETED"
    And Sunita sees the warning that earnings are on hold
    And Sunita's earning is "ON_HOLD"
    And no "CARETAKER_FEE" payment request is created
    When Asha taps "Review final bill" on the visit completed screen
    Then the unpaid requests screen lists "PR-H-01" with "View" and "Approve & Pay"
    And "Review final bill" is disabled

  @ui @api @REQ-F2
  Scenario: Paying the last unpaid request unlocks the final bill
    Given booking "PC-2481" is "COMPLETED" and "PR-H-01" for ₹500 is the only unpaid request
    When Asha pays "PR-H-01" from the unpaid requests screen
    Then "Review final bill" becomes enabled
    And the backend calculates the final caretaker fee

  @api @REQ-D5
  Scenario: Visit Completed requires every handover item
    Given Sunita is on the handover screen with 3 of 4 checklist items ticked
    Then "Mark Visit Completed" is disabled

  @ui @REQ-F4 @REQ-F5
  Scenario: Caretaker can nudge the family or raise a dispute while on hold
    Given Sunita's earning for "PC-2481" is "ON_HOLD"
    When Sunita opens visit earnings
    Then "Notify family" and "Raise a dispute" are available
    When Sunita raises a dispute with reason "Family hasn't cleared payments"
    Then a dispute ticket number matching "DS-\d+" is shown with its SLA

  # ---------- Fee calculation (proposed strategy) ----------

  @api @proposed-rule @smoke @REQ-CTX2-fee
  Scenario Outline: Final caretaker fee by billable time
    Given booking "PC-2481" has purposes "<purposes>"
    And pickup OTP was verified and Visit Completed was marked <actual> later
    And all other payment requests on the booking are "PAID"
    When the backend calculates the final caretaker bill
    Then billed duration is <billed>
    And the net is "<net>"
    And the F1 primary action is "<action>"

    Examples: Over 3 hours rounds up to the next 30 minutes
      | purposes | actual  | billed  | net            | action                |
      | OPD      | 3 h 00m | 3 h 00m | ₹0             | Approve & close visit |
      | OPD      | 3 h 05m | 3 h 30m | to pay ₹125    | Pay Caretaker ₹125    |
      | OPD      | 3 h 30m | 3 h 30m | to pay ₹125    | Pay Caretaker ₹125    |
      | OPD      | 3 h 40m | 4 h 00m | to pay ₹250    | Pay Caretaker ₹250    |
      | OPD      | 5 h 01m | 5 h 30m | to pay ₹625    | Pay Caretaker ₹625    |

    Examples: Under 3 hours keeps the 3-hour minimum
      | purposes | actual  | billed  | net | action                |
      | OPD      | 1 h 20m | 3 h 00m | ₹0  | Approve & close visit |

  @api @proposed-rule
  Scenario: Margin and platform fee never change at settlement
    Given billable time is 4 h 00m
    When the backend calculates the final caretaker bill
    Then the bill shows margin ₹400 and platform fee ₹99 unchanged
    And only caretaker wage lines change

  @api @proposed-rule @pending-clarification
  Scenario Outline: Ambiguous fee boundaries
    Given booking "PC-2481" has purposes "<purposes>" and billable time <actual>
    When the backend calculates the final caretaker bill
    Then the result matches the rule confirmed by the product owner
    # <question>

    Examples:
      | purposes         | actual      | question                                                        |
      | OPD              | 3 h 00m 01s | Does one extra second round up to a 30-minute step?             |
      | OPD, DIAGNOSTICS | 1 h 10m     | Is a mixed visit pro-rated or held to the 3-hour minimum?       |
      | ADMISSION_DISCHARGE | 1 h 00m  | Is the drop-off leg skipped and does that change billable time? |

  @ui @REQ-F1
  Scenario: Final caretaker bill content
    Given billable time was 3 h 40m from 09:58 to 13:38
    When Asha opens the final caretaker bill
    Then it shows a bar of actual time against the 3-hour block
    And it shows "09:58 → 13:38", billed duration "4 h 00m", fee lines and amount paid at booking ₹1,249
    And it shows net "to pay ₹250" and the rule text
    And it shows what was already paid on this visit split into booking, rides and hospital bills

  @api @security @REQ-F1
  Scenario: Caretaker fee amount is computed only by the backend
    Given billable time was 3 h 40m
    When the app requests payment of the caretaker fee with an amount of ₹1
    Then the "CARETAKER_FEE" request and the Razorpay Order are for ₹250

  @api @REQ-F1
  Scenario: Billable time uses server timestamps
    Given the pickup OTP was verified at server time 09:58
    And Visit Completed was recorded at server time 13:38
    And the caretaker's device clock is 20 minutes fast
    When the final bill is calculated
    Then billable time is 3 h 40m

  # ---------- Earnings wallet ----------

  @ui @api @REQ-P1 @REQ-F4
  Scenario: Paid caretaker fee credits the earnings wallet
    Given Sunita's earnings wallet shows ₹2,000
    And Sunita's earning for "PC-2481" is ₹1,000 (block ₹750 + extra time ₹250) and "AWAITING_FEE"
    When Asha's "CARETAKER_FEE" payment of ₹250 is captured and verified
    Then Sunita's earning becomes "IN_WALLET" with a bill number
    And the P1 earnings chip shows ₹3,000
    And visit earnings shows the tracker at "bill generated & added to wallet"

  @ui @REQ-P1
  Scenario: Earnings chip is display only
    When Sunita taps the earnings chip on Home
    Then nothing happens

  @ui @REQ-P9a
  Scenario: Caretaker never pays charges with own money
    Given a ride payment request for ₹286 is "REQUESTED"
    When Sunita views the ride payment screen
    Then there is no option for Sunita to pay the fare
    And "Continue" stays disabled until Asha has paid

  # ---------- Withdrawal (assumed RazorpayX) ----------

  @api @ui @payout @pending-clarification
  Scenario: Withdrawal to the verified bank account
    Given Sunita's earning for "PC-2481" is "IN_WALLET" for ₹1,000
    And Sunita's bank account ending "4321" was verified by a ₹1 test deposit
    When Sunita taps "Withdraw ₹1,000 to bank"
    Then a RazorpayX payout of 100000 paise is created to Sunita's fund account
    When RazorpayX reports the payout as processed with a UTR
    Then the earning becomes "WITHDRAWN"
    And visit earnings shows bank "•••• 4321" and the UTR
    And the earnings chip decreases by ₹1,000

  @api @payout @idempotency @pending-clarification
  Scenario: Double tap on Withdraw creates one payout
    Given Sunita's earning is "IN_WALLET" for ₹1,000
    When Sunita taps "Withdraw ₹1,000 to bank" twice
    Then exactly one RazorpayX payout exists for that amount

  @api @payout @negative @pending-clarification
  Scenario Outline: Withdrawal is refused when it should not happen
    Given <condition>
    When Sunita requests a withdrawal
    Then no payout is created

    Examples:
      | condition                                          |
      | Sunita's bank validation status is "FAILED"         |
      | Sunita's earning is still "ON_HOLD"                 |
      | Sunita's wallet balance is ₹0                       |
