# Traceability: Context §3 "return payment status on app resume", Critical rule: client callback alone never
#               establishes success.
# Razorpay rule: valid signature = HMAC-SHA256(razorpay_order_id + "|" + razorpay_payment_id, Key Secret).
# The backend must also check that the order ID is the one it stored for this item and that the payment's
# amount, currency and status (fetched from Razorpay) match.
@payments @signature @api @security
Feature: Backend verification of the Razorpay payment response
  As the Proxy Care backend
  I want to verify every Checkout response against Razorpay and my own records
  So that a forged or replayed response can never mark anything as paid

  Background:
    Given the Proxy Care backend is connected to Razorpay in test mode
    And a signed-in User "Asha Verma"
    And payment request "PR-H-01" for ₹500 is "PAYING" with stored Razorpay Order "order_H01"
    And Razorpay holds payment "pay_H01" on "order_H01" captured for 50000 paise INR

  @smoke
  Scenario: Valid signature, matching order and captured payment
    When the app submits order "order_H01", payment "pay_H01" and a correct signature for "PR-H-01"
    Then the backend computes the signature with the Key Secret and it matches
    And the backend confirms with Razorpay that "pay_H01" is captured for 50000 paise INR on "order_H01"
    And "PR-H-01" becomes "PAID"

  Scenario Outline: Tampered or mismatched responses are rejected
    When the app submits order "<order>", payment "<payment>" and signature "<signature>" for "PR-H-01"
    Then the backend rejects the verification
    And "PR-H-01" is not marked "PAID" by this call
    And the attempt is logged as a security event without secrets

    Examples:
      | order        | payment     | signature                           |
      | order_H01    | pay_H01     | a random 64-hex string              |
      | order_H01    | pay_H01     | (empty)                             |
      | order_H01    | pay_OTHER   | signature valid for pay_H01         |
      | order_OTHER  | pay_H01     | signature valid for order_OTHER     |
      | order_H01    | pay_H01     | HMAC computed with the Key ID       |
      | order_H01    | pay_H01     | HMAC of "pay_H01\|order_H01" (swapped order) |
      | (empty)      | pay_H01     | signature valid for pay_H01         |

  Scenario: Signature is valid but the order belongs to a different payment request
    Given payment request "PR-R-01" of Asha has Razorpay Order "order_R01" paid for 28600 paise
    When the app submits a correct signature for "order_R01" and its payment against "PR-H-01"
    Then the backend rejects the verification
    And neither "PR-H-01" nor "PR-R-01" changes because of this call

  Scenario: Signature is valid but the payment is only authorized
    Given Razorpay holds payment "pay_H01" as "authorized", not captured
    When the app submits a correct signature for "order_H01" and "pay_H01"
    Then "PR-H-01" stays "PAYING"

  Scenario: Signature is valid but the captured amount differs
    Given Razorpay holds payment "pay_H01" captured for 100 paise
    When the app submits a correct signature for "order_H01" and "pay_H01"
    Then "PR-H-01" is not marked "PAID"
    And the mismatch is raised for manual review

  Scenario: Replaying a successful verification is harmless
    Given "PR-H-01" was verified and is "PAID"
    When the same order, payment and signature are submitted again
    Then the backend returns the current "PAID" status
    And no second Payment record, alert or earning is created

  Scenario: Replaying another User's valid response is refused
    Given User "Ravi Kumar" has a valid verified response for his own payment request
    When Asha's session submits Ravi's order, payment and signature
    Then the backend responds 403 or 404
    And nothing changes on either User's records

  Scenario: Verification requires an authenticated User who owns the item
    When an unauthenticated client submits a correct signature for "order_H01" and "pay_H01"
    Then the backend responds 401
    But the payment can still be confirmed through the Razorpay webhook

  @mock-razorpay @negative
  Scenario: Razorpay API is down while the backend confirms the payment
    Given the Razorpay Payments API is stubbed to return HTTP 503
    When the app submits a correct signature for "order_H01" and "pay_H01"
    Then "PR-H-01" is not marked "PAID" from this call alone
    And the app shows a status-pending state
    And "PR-H-01" is updated once the webhook or reconciliation confirms the capture

  @ui
  Scenario: The app never shows success from the Checkout callback alone
    Given the backend verification for "PR-H-01" has not yet returned
    When the Checkout success callback fires on the device
    Then the app shows a processing state
    And "₹500 paid" is shown only after the backend reports "PAID"
