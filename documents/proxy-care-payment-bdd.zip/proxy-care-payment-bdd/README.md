# Proxy Care · Payment System BDD suite (Razorpay)

22 feature files · 243 scenarios · 297 Examples rows. Source of truth: `proxy-care-api-context.md` (PRD v2.3
alignment, 1 Nov 2026), `product-requirement-document.md` v2.3, `Entity_Design_Document.txt`.

- `features/` — Gherkin files, numbered in journey order
- `test-data/razorpay_test_fixtures.md` — Razorpay test-mode cards/UPI and seed data
- `COVERAGE_AND_GAPS.md` — per-file coverage, Razorpay coverage, gaps, ambiguities, assumptions, mocks

## Tag legend

| Tag | Meaning | How to run |
|---|---|---|
| `@ui` | App screen behaviour (User or Caretaker app) | Appium / Detox / Playwright-mobile |
| `@api` | Proxy Care backend contract | REST client |
| `@gateway` | Real Razorpay test-mode calls | needs `rzp_test_` keys |
| `@sandbox` | Needs Razorpay dashboard configuration | see fixtures file |
| `@mock-razorpay` | Razorpay API must be stubbed to force errors/timeouts | WireMock or similar |
| `@webhook-sim` | Signed webhook simulator posting to the endpoint | HMAC with test webhook secret |
| `@static-check` | Build / log / traffic inspection | CI security job |
| `@capture-auto` / `@capture-manual` | Run only the set matching the Razorpay capture config | |
| `@payout` | RazorpayX caretaker withdrawals (assumed) | RazorpayX test mode |
| `@proposed-rule` | Final fee strategy marked "proposed, pending confirmation" | expect churn |
| `@pending-clarification` | Behaviour not specified; expected result to be confirmed | exclude from blocking runs |
| `@pending-method-confirmation` | Depends on which payment methods are enabled | |
| `@smoke` | Minimum release gate | |
| `@REQ-<screen>` / `@REQ-CTX<n>` / `@REQ-PRD-<n>` | Traceability to screen ID, context section or PRD section | |

Suggested gates: `@smoke and not @pending-clarification` on every merge; full suite minus
`@pending-clarification` nightly; `@pending-clarification` reviewed with product each sprint.

## Step-writing conventions

- Amounts in prose are rupees (`₹500`); amounts sent to Razorpay are paise (`50000`). Currency is always INR.
- Status names match the docs exactly: payment request `REQUESTED / PAYING / PAID / FAILED / DISPUTED`,
  booking `PAYMENT_PENDING / WAITING / ASSIGNED / IN_PROGRESS / COMPLETED / SETTLED / CANCELLED`,
  hospital bill `QR_MISMATCH / PAYMENT_REQUESTED / PAID_BILL_PENDING / BILL_ATTACHED / DISPUTED`,
  earning `ON_HOLD / AWAITING_FEE / IN_WALLET / WITHDRAWN`. Razorpay statuses are lower-case
  (`created / attempted / paid`, `authorized / captured / failed / refunded`, `pending / processed / failed`).
- "verified" in a step means: backend signature check passed **and** Razorpay confirms a captured payment of the
  stored amount. No step treats the Checkout callback alone as success.
- Steps name business outcomes, not endpoints; endpoint paths are not documented and are left to step definitions.
