# Proxy Care Payment System — coverage, gaps and assumptions

Analysed 2 Nov 2026 against `proxy-care-api-context.md`, PRD v2.3 and `Entity_Design_Document.txt`.

## 1. What the payment system is (as documented)

- **Collection:** every charge the User pays goes through Razorpay into the Proxy Care account. No User wallet.
- **Five payable items:** the booking charge (B4, "Confirm & Pay") and four payment request types paid with
  "Approve & Pay": `RIDE_TO_HOSPITAL`, `HOSPITAL_BILL`, `RIDE_HOME`, `CARETAKER_FEE`.
- **Refunds:** cancellation (policy by hours before pickup) and Diagnostics pro-rate (proposed rule).
- **Caretaker side:** never pays; raises ride and hospital requests; earnings land in a virtual wallet once the
  caretaker fee is paid; withdrawal to bank (assumed RazorpayX).

## 2. Per-file coverage summary

| # | File | Scenarios | Covers |
|---|---|---|---|
| 01 | payment_initiation | 10 | B4 price by mobility, end-to-end booking payment, server-side pricing and snapshot, Approve & Pay for all 4 request types, Home pending list, H5/U2b content, ride fare source |
| 02 | payment_methods | 11 | Enabled-method listing, success per card/UPI/NB/wallet, 8 Razorpay failure codes, OTP failure, UPI failure, Checkout card/UPI field validation, international card, ₹1 minimum, per-method limit |
| 03 | payment_form_validation | 14 | B4 policy checkbox (UI + API), QR checks matrix, non-UPI QR, no upload fallback, H2a amount read-only vs typed, amount/description bounds, quick chips, backend QR re-check, amount source, H4 attach enablement and limits |
| 04 | razorpay_order_creation | 14 | Order for booking and request, receipt/notes mapping, trusted amount, invalid amount/currency, non-payable states, QR_MISMATCH, Razorpay 4xx/5xx/timeout/malformed, backend 500, repeat taps, retry after failure, missing order ID, order mismatch, stale order |
| 05 | razorpay_checkout | 11 | Open with correct amount/merchant/prefill, success return, close/back/failure, init failure, bad config (key, order, amount), network loss after/before pay, app killed, single Checkout, idle timeout |
| 06 | razorpay_authorization_capture | 9 | Authorized ≠ paid, auth failures, auto capture, uncaptured auto-refund, manual capture, invalid/over/under capture, duplicate capture, capture timeout, captured-amount mismatch |
| 07 | payment_success | 6 | Business effects per type: booking WAITING + broadcast, ride unblocks caretaker, hospital bill → attach bill → B9, caretaker fee → SETTLED + wallet, B8/B9 listing, Home list update |
| 08 | payment_failure | 10 | Booking failure (no dispatch), request failure per type, retry success with one capture, backend 5xx/timeout, API 401/403/404/409, missing callback, missing callback and webhook, missing signature field, failure screen hygiene |
| 09 | payment_cancellation | 11 | Cancel at gateway, B5 quote with the documented examples + 8h boundary, quote per mobility, re-quote at confirm, confirm → CANCELLED + refund + toast + B7, keep booking, expire offers, double confirm, accept/cancel race, non-WAITING states, no-show |
| 10 | razorpay_webhooks | 18 | Signature valid/missing/wrong/tampered/raw-body, bad payloads, unknown events, each payment and refund event, duplicate event ID, cross-event dedupe, webhook vs verify race, out-of-order, refund ordering, retry on error, 5 s ack, endpoint down + reconciliation, 24 h disable |
| 11 | razorpay_signature_verification | 10 | Valid path, 7 tamper variants, cross-request reuse, authorized-only, amount mismatch, replay, other User's response, unauthenticated, Razorpay API down, UI never trusts callback |
| 12 | payment_transaction_status | 12 | Allowed/forbidden request transitions, abandon semantics, booking/hospital bill/earning state machines, QR_MISMATCH terminal, resume polling, cross-app consistency, reconciliation mapping, duplicate capture |
| 13 | razorpay_refunds | 13 | Cancellation refunds (>8h, <8h), Diagnostics pro-rate, non-diagnostics no refund, status sync, failed and delayed refunds, amount guard rails, invalid payment, duplicate refund, refund timeout, refund authorization, statement |
| 14 | final_settlement_and_earnings | 16 | F2 blocking, unlock after last payment, checklist gate, notify/dispute while on hold, fee rounding table, margin/fee constant, ambiguous boundaries, F1 content, server-computed fee and time, wallet credit, display-only chip, caretaker never pays, withdrawal + idempotency + guards |
| 15 | hospital_bill_dispute | 6 | Dispute before paying, disputed not payable, F2 entry, dispute eligibility, dispute vs settlement, post-payment problem report |
| 16 | payment_notifications | 12 | Request banners per type, caretaker paid/failed alerts, bill attached, wallet update, withdrawal, settlement reminder, cancel toast, push in background, push failure, no duplicate alerts, amount accuracy, no sensitive data |
| 17 | payment_history | 10 | B8 grouping incl. booking charge, empty state, B9 per type, Bills section, bill pending, receipt PDF, F3 totals and invoice, Razorpay reference match, B7 chips, other User's payment |
| 18 | payment_navigation | 11 | Landing after each outcome per screen, F3 close, F2 redirect, tab entry points, caretaker continue targets, H3↔H4, D5 → F4, back from Checkout, back after success, stale banners, unknown deep link |
| 19 | payment_access_control | 8 | 14-row role/action matrix, view permissions, ID enumeration, request creation only when in progress, closed bookings, amount immutability, dual-role profile, refund endpoints |
| 20 | payment_security | 11 | Secrets absent from apps, test keys only, no sensitive data in logs/DB, webhook payload storage, HTTPS, tampered amount/currency/booking/payee, no callback-only success, QR swap, rate limiting, pickup code secrecy, hospital disbursement target |
| 21 | payment_retry_idempotency | 11 | Multi-tap booking, two-device booking, two-device request payment, timeout then retry, pay after closing Checkout, restart, 7 repeat-operation rows, Send to family twice, ride request twice, optimistic rollback, reconciliation reruns |
| 22 | payment_ui_states | 9 | 10-row pay-screen state table, loading, error + retry, empty states, H3 states, upload states, session expiry, offline, F1 net actions |

## 3. Overall coverage

- Every documented payable item is covered from creation to final state, on both apps where both are involved.
- Every documented status enum is exercised with allowed and forbidden transitions.
- All four cancellation examples from the docs are reproduced verbatim; the exact-8h case is isolated.
- Financial integrity checks: server-side amount, order/request binding, signature, captured-amount match,
  refund ≤ captured, no double capture/refund/credit, reconciliation.

## 4. Razorpay integration coverage

| Area | Covered | Note |
|---|---|---|
| Orders API | ✔ create, receipt/notes, errors, timeout, reuse | Order validity window not documented |
| Checkout | ✔ open, prefill, return, close, back, init/config errors, network loss | Integration type (SDK vs web vs Payment Link) unknown |
| Payment methods | ✔ card, UPI, NB, wallet with official test fixtures | Enabled list unknown → `@pending-method-confirmation` |
| Signature | ✔ HMAC(order_id\|payment_id), 7 tamper cases, replay | |
| Authorization / capture | ✔ both modes, tagged separately | Capture mode unknown |
| Webhooks | ✔ payment.authorized/captured/failed, order.paid, refund.created/processed/failed; HMAC; event-id idempotency; ordering; retries; 5 s ack; 24 h disable | Subscribed event list unknown |
| Refunds | ✔ partial, guard rails, status, failure, duplicates | Speed (normal/optimum) unknown |
| RazorpayX payouts | ✔ light (`@payout`) | Mechanism assumed from entity fields only |
| Reconciliation | ✔ polling Razorpay for PAYING items | Schedule not documented |

## 5. Uncovered requirements (not testable from the docs)

1. **Onward payment to the hospital and ride partner.** Users pay Proxy Care, but nothing says how the hospital
   desk (QR payee) or Uber/Rapido is paid, or when. The "desk is waiting" note implies near-real-time
   disbursement. Only a placeholder security scenario exists.
2. **Payment history search, filters, sorting, pagination** — not designed for B8.
3. **Email and SMS payment notifications** — not documented (SMS only for OTP and pickup code).
4. **Admin / operations tooling** — no role, refund console or dispute resolution flow.
5. **No-caretaker-found timeout on B5** and the refund it implies.
6. **Cancellation after assignment** and the no-show flow.
7. **Payment-failed screens** are described but not drawn (copy and layout unknown).
8. **Withdrawal UX and rules** (minimum, frequency, partial withdrawal).
9. **Responsive/tablet layouts.**

## 6. Missing API or UI documentation dependencies

- No endpoint list, request/response schemas or error codes for: create order, verify payment, payment status,
  cancellation quote, cancel booking, list payments, payment detail, receipt, invoice, withdrawal.
- **Entity design has no tables for** payment requests, payments (gateway transactions), refunds, cancellations,
  caretaker earnings, withdrawals, or invoices (the "Croissant" note asks for invoices). These are central to
  every scenario here.
- No Razorpay configuration record: Checkout integration type, enabled methods, capture mode, refund speed,
  subscribed webhook events, order receipt/notes format, customer creation (`razorpay_customer_id` is only in
  the "donut" notes).
- Exact UI copy for errors, processing and pending states (only success copy like "₹X paid" is given).
- Transaction ID meaning on B9: app Payment ID or Razorpay Payment ID?

## 7. Ambiguous or conflicting business rules

| # | Topic | Conflict |
|---|---|---|
| A1 | Booking creation timing | State machine starts at `PAYMENT_PENDING`, but B4 says the booking is created `WAITING` on success and `bookings.state` defaults to `WAITING`. Is a booking row created before payment? |
| A2 | Exactly 8 h before pickup | Unspecified (Context §9). |
| A3 | Late cancellation amount | PRD says ₹600 base; UI uses the patient's 3-hour wage (₹600/₹750/₹960). |
| A4 | Refund destination | "Bank account / original payment method". Razorpay refunds go to the original source; refunding to a bank account for a card/UPI payment needs a different mechanism. |
| A5 | Fee rounding granularity | Does 3 h 00 m 01 s round up to 3 h 30 m? |
| A6 | Mixed Diagnostics visits | "Except Diagnostics" — is OPD + Diagnostics pro-rated? |
| A7 | Zero or refund net and `SETTLED` | `SETTLED` = "caretaker fee paid", but there is no fee request when the net is ₹0 or a refund. |
| A8 | Earning when net is ₹0 | Does the earning skip `AWAITING_FEE` and go straight to `IN_WALLET`? |
| A9 | Abandoned Checkout | Does the request go `PAYING → REQUESTED`, stay `PAYING`, or become `FAILED`? |
| A10 | Disputed hospital bills | Do they block F2/F1? Who resolves them? Can they go back to `REQUESTED`? |
| A11 | Hospital bill attachment | Is it mandatory before Leave hospital / Visit Completed? H4 file limits? |
| A12 | Duplicate captures | What happens if two payments are captured for one request (two devices, late UPI approval)? |
| A13 | PRD 3.6 step 5 | Says "pay the transit charges" for the caretaker fee — copy-paste error. |
| A14 | Ride request amount | P8a says "Request ₹X"; is X the final fare (assumed) or the estimate? |
| A15 | Admission-only visits | Drop-off leg skipped? Affects ride-home request and billable time. |
| A16 | Dual-role profiles | `profiles.roles` allows USER + CARETAKER; can a person serve their own booking? |
| A17 | Hospital amount ceiling | No maximum for typed hospital amounts; also UPI per-transaction limits. |
| A18 | Entity doc issues affecting payments | `bookings.actual_minutes` and `settlement_status` are NOT NULL at creation; `hospital_bills.checks` is boolean but the comment shows JSON; `rides` index uses `leg` but the column is missing; `idempotency_key` marked "FOR LATER" though the UI requires idempotency. |

## 8. Recommended additional scenarios (once rules are confirmed)

- Disbursement to the hospital VPA and ride partner, including failure and reversal.
- Booking timeout with automatic full refund.
- Cancellation after assignment and no-show settlement.
- Payment request expiry (if requests should expire when a visit ends).
- Razorpay chargebacks/disputes (`payment.dispute.*` webhooks) on User payments.
- Load tests: concurrent payments across many bookings; webhook bursts.
- Accessibility of pay screens (screen reader labels for amounts, button states).
- Hindi (`hi`) copy for every payment state.
- Monthly reconciliation of Razorpay settlements against Proxy Care records.

## 9. Assumptions made

1. Razorpay Orders API + Checkout + signature verification is the integration pattern; the "redirect" in the docs
   is Checkout opening and returning.
2. A payment request is marked `PAID` only on a captured payment of the stored amount.
3. Order receipt/notes carry booking and request references for reconciliation.
4. The Razorpay order is created for the stored amount; client amounts are ignored.
5. Booking draft details are kept after a failed booking payment so the User can retry.
6. Ride requests use the ride partner's final fare.
7. Caretaker earning = hourly wage × billed hours (block + extra); margin and fee stay with Proxy Care.
8. Withdrawals use RazorpayX payouts to the verified fund account, and the earnings chip drops on withdrawal.
9. Webhook events are stored in `webhook_events` keyed by `x-razorpay-event-id`.
10. Push notifications use the FCM tokens in `device_tokens`.
11. A reconciliation job polls Razorpay for items stuck in `PAYING`.
12. Times are Asia/Kolkata; billable time uses server timestamps.

## 10. Scenarios needing Razorpay sandbox configuration

- All `@gateway` and `@sandbox` scenarios: test Key ID/Secret, a test webhook secret, the webhook URL registered
  in test mode.
- `02_payment_methods`: enabled-method list matching production; international cards toggled off (or on) as in prod.
- `06_*`: capture mode set per tag set (`@capture-auto` / `@capture-manual`).
- `13_razorpay_refunds`: refunds enabled with the same speed as production.
- `14_*` `@payout`: RazorpayX test account, contact and fund account for "Sunita Rao".

## 11. Scenarios needing webhook simulation or backend mocking

- **Webhook simulator (`@webhook-sim`)**: all of `10_razorpay_webhooks`, plus the webhook paths in 05, 08, 12,
  13, 16, 21. Must sign the raw body with the test secret and set `x-razorpay-event-id`; must be able to resend,
  delay and reorder.
- **Razorpay API stubs (`@mock-razorpay`)**: order creation errors/timeouts (04), Checkout init failure and bad
  config (05), capture timeout (06), verification-time API outage (11), refund timeout (13), endpoint-down and
  reconciliation (10), DB outage on webhook (10).
- **Clock control**: cancellation quotes (09), fee calculation and billable time (13, 14).
- **Realtime/push harness**: banners and alerts across two app sessions (07, 16, 18), FCM stub (16).
- **Two-device harness**: concurrent payments and cancellations (09, 21).

## Sources (Razorpay behaviour)

- [Razorpay custom web integration — test integration](https://razorpay.com/docs/payments/payment-gateway/web-integration/custom/test-integration.md)
- [Razorpay test card details](https://razorpay.com/docs/payments/payments/test-card-details.md)
- [Razorpay webhooks — best practices](https://razorpay.com/docs/sg/webhooks/best-practices)
- [Razorpay webhooks — validate and test](https://razorpay.com/docs/webhooks/validate-test)
